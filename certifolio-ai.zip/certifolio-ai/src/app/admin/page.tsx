'use client';

import { useEffect, useState } from 'react';
import Icon from '@/components/Icon';
import { useToast } from '@/components/admin/Toast';
import { getBrowserClient } from '@/lib/supabase/client';
import { BUCKET, fmtSize } from '@/lib/utils';

const TABLES: [string, string][] = [
  ['certificates', 'Certificates'],
  ['projects', 'Projects'],
  ['experiences', 'Experience'],
  ['achievements', 'Achievements'],
  ['skills', 'Skills'],
];
const FOLDERS = ['certificates', 'projects', 'achievements', 'resumes', 'profile'];
const FREE_PLAN_BYTES = 1024 * 1024 * 1024; // about 1 GB; check supabase.com/pricing for current limits

type Counts = Record<string, { total: number; live: number }>;

export default function OverviewPage() {
  const supabase = getBrowserClient();
  const toast = useToast();
  const [counts, setCounts] = useState<Counts>({});
  const [used, setUsed] = useState<number | null>(null);
  const [checks, setChecks] = useState<{ photo: boolean; bio: boolean; resume: boolean }>({ photo: false, bio: false, resume: false });
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);

  useEffect(() => {
    let active = true;
    (async () => {
      const next: Counts = {};
      for (const [table] of TABLES) {
        const pubCol = table === 'skills' ? 'is_public' : 'published';
        const all = await supabase.from(table).select('id', { count: 'exact', head: true });
        const live = await supabase.from(table).select('id', { count: 'exact', head: true }).eq(pubCol, true);
        next[table] = { total: all.count ?? 0, live: live.count ?? 0 };
      }
      let bytes = 0;
      for (const folder of FOLDERS) {
        const { data } = await supabase.storage.from(BUCKET).list(folder, { limit: 1000 });
        (data ?? []).forEach((o: any) => {
          bytes += Number(o?.metadata?.size ?? 0);
        });
      }
      const profile = await supabase.from('site_profile').select('bio,photo_path').eq('id', 1).maybeSingle();
      const resume = await supabase.from('resumes').select('id', { count: 'exact', head: true }).eq('is_published', true);
      if (!active) return;
      setCounts(next);
      setUsed(bytes);
      setChecks({ photo: Boolean(profile.data?.photo_path), bio: Boolean(profile.data?.bio), resume: (resume.count ?? 0) > 0 });
      setLoading(false);
    })().catch(() => {
      if (active) setLoading(false);
    });
    return () => {
      active = false;
    };
  }, [supabase]);

  async function exportAll() {
    setExporting(true);
    try {
      const out: Record<string, unknown> = { exported_at: new Date().toISOString() };
      for (const t of ['site_profile', 'skills', 'certificates', 'projects', 'experiences', 'achievements', 'resumes']) {
        const { data, error } = await supabase.from(t).select('*');
        if (error) throw new Error(`${t}: ${error.message}`);
        out[t] = data;
      }
      const blob = new Blob([JSON.stringify(out, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `certifolio-backup-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
      toast('Backup downloaded. It contains your records, not the uploaded files.', 'good');
    } catch (e: any) {
      toast(e?.message ? `Export failed: ${e.message}` : 'Export failed.', 'bad');
    } finally {
      setExporting(false);
    }
  }

  const published = Object.entries(counts)
    .filter(([t]) => t !== 'skills')
    .reduce((n, [, c]) => n + c.live, 0);
  const drafts = Object.entries(counts)
    .filter(([t]) => t !== 'skills')
    .reduce((n, [, c]) => n + (c.total - c.live), 0);

  const steps: [boolean, string][] = [
    [checks.photo, 'Upload your professional photo (Profile)'],
    [checks.bio, 'Write your About text (Profile)'],
    [checks.resume, 'Upload and publish your resume (Resume)'],
    [(counts.certificates?.live ?? 0) > 0, 'Publish your first certificate (Certificates)'],
    [(counts.projects?.live ?? 0) > 0, 'Complete and publish a project (Projects)'],
    [(counts.skills?.live ?? 0) > 0, 'Add the skills you want to show (Skills)'],
  ];

  return (
    <>
      <div className="ahead">
        <h2>Overview</h2>
        <a className="btn primary" href="/" target="_blank" rel="noopener noreferrer">
          <Icon name="eye" />
          Preview public site
        </a>
      </div>

      {loading ? (
        <p style={{ color: 'var(--fg2)' }} role="status">
          Loading...
        </p>
      ) : (
        <>
          <div className="stats">
            <div className="stat">
              <b>{published}</b>
              <span>Published items</span>
            </div>
            <div className="stat">
              <b>{drafts}</b>
              <span>Drafts</span>
            </div>
            {TABLES.map(([t, label]) => (
              <div className="stat" key={t}>
                <b>{counts[t]?.total ?? 0}</b>
                <span>{label}</span>
              </div>
            ))}
          </div>

          <div className="panel">
            <h3>Set up your portfolio</h3>
            <ul className="todo">
              {steps.map(([done, label]) => (
                <li key={label} className={done ? 'done' : ''}>
                  <span className="dot">{done ? <Icon name="check" /> : null}</span>
                  {label}
                </li>
              ))}
            </ul>
          </div>

          <div className="panel">
            <h3>Storage</h3>
            <p style={{ color: 'var(--fg2)' }}>
              Files stored: {used === null ? 'unknown' : fmtSize(used)} of about 1 GB on the Supabase free plan. Each file is limited to 10 MB
              here (5 MB for the resume and photo). Check supabase.com/pricing for current plan limits.
            </p>
            <div className="meter" role="img" aria-label="Storage used">
              <i style={{ width: `${Math.min(100, ((used ?? 0) / FREE_PLAN_BYTES) * 100)}%` }} />
            </div>
          </div>

          <div className="panel">
            <h3>Backup</h3>
            <p style={{ color: 'var(--fg2)', marginBottom: 10 }}>
              Download all your records as a JSON file. Uploaded files are not included, so keep the originals too.
            </p>
            <button className="btn" type="button" onClick={exportAll} disabled={exporting}>
              <Icon name="down" />
              {exporting ? 'Preparing...' : 'Download backup (JSON)'}
            </button>
          </div>
        </>
      )}
    </>
  );
}
