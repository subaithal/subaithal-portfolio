import type { ReactNode } from 'react';
import Icon from '@/components/Icon';
import SiteNav from '@/components/SiteNav';
import { getSiteData, type Row } from '@/lib/public-data';
import { fmtDate, safeUrl } from '@/lib/utils';

export const revalidate = 60;

const DEFAULT_LINKEDIN = 'https://www.linkedin.com/in/subaithal-s-812584426';
const DEFAULT_GITHUB = 'https://github.com/Subaithals';

const ENTRY_LABELS: Record<string, { label: string; tone: string }> = {
  applied: { label: 'Application submitted', tone: 'mute' },
  shortlisted: { label: 'Shortlisted', tone: 'warn' },
  selected: { label: 'Selected (confirmed)', tone: 'pur' },
  ongoing: { label: 'Ongoing', tone: 'ok' },
  completed: { label: 'Completed', tone: 'ok' },
};

function Empty({ title, text }: { title: string; text: string }) {
  return (
    <div className="empty">
      <b>{title}</b>
      <span>{text}</span>
    </div>
  );
}

function Section({ id, title, intro, children }: { id: string; title: string; intro?: string; children: ReactNode }) {
  return (
    <section className="sec" id={id}>
      <div className="wrap">
        <div className="sechead">
          <h2>{title}</h2>
          {intro ? <p>{intro}</p> : null}
        </div>
        {children}
      </div>
    </section>
  );
}

function ExtLink({ href, children, primary }: { href: string | null; children: ReactNode; primary?: boolean }) {
  if (!href) return null;
  return (
    <a className={`btn sm${primary ? ' primary' : ''}`} href={href} target="_blank" rel="noopener noreferrer">
      {children}
    </a>
  );
}

function SetupNotice() {
  return (
    <main id="main" className="wrap" style={{ paddingBlock: '72px' }}>
      <div className="empty">
        <b>Almost there: connect Supabase</b>
        <span>
          This site is deployed, but it cannot reach its database yet. Add NEXT_PUBLIC_SUPABASE_URL and
          NEXT_PUBLIC_SUPABASE_ANON_KEY in your hosting settings (Vercel: Project Settings, Environment Variables),
          then redeploy. The README lists every step.
        </span>
      </div>
    </main>
  );
}

export default async function HomePage() {
  const data = await getSiteData();
  if (!data) {
    return (
      <>
        <SiteNav />
        <SetupNotice />
      </>
    );
  }

  const { profile, skills, certs, projects, exps, achs, resume, urls } = data;
  const linkedin = safeUrl(profile.linkedin) || DEFAULT_LINKEDIN;
  const github = safeUrl(profile.github) || DEFAULT_GITHUB;
  const photo: string | undefined = profile.photo_path ? urls[profile.photo_path] : undefined;
  const resumeUrl: string | undefined = resume?.file_path ? urls[resume.file_path] : undefined;

  const cats = Array.from(new Set(skills.map((s: Row) => s.category)));

  const hub = (id: string, label: string, n: number) => (
    <a className="hubc" href={`#${id}`} key={id}>
      <h3>
        {label}
        <Icon name="arrow" />
      </h3>
      <small>{n ? `${n} published` : 'Nothing published yet'}</small>
    </a>
  );

  return (
    <>
      <SiteNav />
      <main id="main">
        <section className="hero" id="home">
          <div className="wrap">
            <div>
              <p className="eyebrow">Hello, I&apos;m</p>
              <h1>
                <em>Subaithal S.</em>
              </h1>
              <p className="lede">
                B.Tech student in Artificial Intelligence and Data Science, interested in Generative AI and AI
                engineering.
              </p>
              <div className="meta">
                <span>
                  <b>Degree</b> · B.Tech Artificial Intelligence and Data Science
                </span>
                <span>
                  <b>College</b> · Thamirabharani Engineering College, Tirunelveli
                </span>
              </div>
              <div className="actions">
                <a className="btn primary" href="#projects">
                  View My Projects <Icon name="arrow" />
                </a>
                {resumeUrl ? (
                  <a className="btn" href={resumeUrl} target="_blank" rel="noopener noreferrer">
                    <Icon name="down" />
                    Download Resume
                  </a>
                ) : null}
                <a className="btn" href={linkedin} target="_blank" rel="noopener noreferrer">
                  <Icon name="li" />
                  LinkedIn
                </a>
                <a className="btn" href={github} target="_blank" rel="noopener noreferrer">
                  <Icon name="gh" />
                  GitHub
                </a>
                <a className="btn ghost" href="#contact">
                  Contact Me
                </a>
              </div>
            </div>
            <div className="portrait">
              <div className="frame">
                {photo ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={photo} alt="Portrait of Subaithal S." />
                ) : (
                  <div className="ph">
                    <div className="mono" aria-hidden="true">
                      SS
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>

        <div className="wrap hub">
          {hub('certificates', 'Certificates', certs.length)}
          {hub('projects', 'Projects', projects.length)}
          {hub('experience', 'Experience', exps.length)}
          {hub('achievements', 'Achievements', achs.length)}
        </div>

        <Section id="about" title="About me">
          {profile.bio ? (
            <p className="lede" style={{ maxWidth: '68ch', whiteSpace: 'pre-wrap' }}>
              {profile.bio}
            </p>
          ) : (
            <Empty title="About text coming soon" text="This section fills in once the owner writes it." />
          )}
        </Section>

        <Section id="skills" title="Skills" intro="Grouped by area and labelled with my current learning stage.">
          {skills.length ? (
            cats.map((c) => (
              <div className="skillgrp" key={c}>
                <h3>{c}</h3>
                {skills
                  .filter((s: Row) => s.category === c)
                  .map((s: Row) => (
                    <div className="skill" key={s.id} title={s.description || undefined}>
                      {s.name}
                      <span>{s.stage}</span>
                    </div>
                  ))}
              </div>
            ))
          ) : (
            <Empty title="No skills published yet" text="Skills appear here after they are reviewed and approved." />
          )}
        </Section>

        <Section
          id="certificates"
          title="Certificates"
          intro="Published certificates only. Skills listed on a certificate are the ones I approved."
        >
          {certs.length ? (
            <div className="grid">
              {certs.map((c: Row) => {
                const file = c.file_path ? urls[c.file_path] : undefined;
                return (
                  <article className="card" key={c.id}>
                    <div>
                      <p className="sub">
                        {c.issuer}
                        {c.issue_date ? ` · ${fmtDate(c.issue_date)}` : ''}
                      </p>
                      <h3>{c.title}</h3>
                    </div>
                    {c.description ? <p className="sum">{c.description}</p> : null}
                    {c.skills?.length ? (
                      <div className="tags">
                        {c.skills.map((s: string) => (
                          <span className="tag on" key={s}>
                            {s}
                          </span>
                        ))}
                      </div>
                    ) : null}
                    {c.tags?.length ? (
                      <div className="tags">
                        {c.tags.map((t: string) => (
                          <span className="tag" key={t}>
                            {t}
                          </span>
                        ))}
                      </div>
                    ) : null}
                    <div className="row">
                      <ExtLink href={file ?? null}>
                        <Icon name="eye" />
                        View certificate
                      </ExtLink>
                      <ExtLink href={safeUrl(c.verify_url)}>
                        <Icon name="ext" />
                        Verify
                      </ExtLink>
                    </div>
                  </article>
                );
              })}
            </div>
          ) : (
            <Empty title="No certificates published yet" text="Certificates appear here once they are reviewed and published." />
          )}
        </Section>

        <Section
          id="projects"
          title="Projects"
          intro="Live demos and source code, with a write-up for each project."
        >
          {projects.length ? (
            <div className="grid">
              {projects.map((p: Row) => (
                <article className="card" key={p.id}>
                  <div>
                    <h3>{p.title}</h3>
                    {p.project_status ? (
                      <p className="sub" style={{ marginTop: 6 }}>
                        {p.project_status}
                      </p>
                    ) : null}
                  </div>
                  <p className="sum">{p.summary || 'Write-up coming soon.'}</p>
                  {p.tech?.length ? (
                    <div className="tags">
                      {p.tech.map((t: string) => (
                        <span className="tag on" key={t}>
                          {t}
                        </span>
                      ))}
                    </div>
                  ) : null}
                  <div className="row">
                    <a className="btn sm" href={`/projects/${p.slug}`}>
                      Details
                    </a>
                    <ExtLink href={safeUrl(p.live_url)} primary>
                      <Icon name="ext" />
                      Live demo
                    </ExtLink>
                    <ExtLink href={safeUrl(p.repo_url)}>
                      <Icon name="gh" />
                      GitHub
                    </ExtLink>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <Empty title="No projects published yet" text="Projects appear here once they are published." />
          )}
        </Section>

        <Section id="experience" title="Experience and internships">
          {exps.length ? (
            <div className="tl">
              {exps.map((e: Row) => {
                const t = ENTRY_LABELS[e.entry_type] || ENTRY_LABELS.applied;
                return (
                  <article className="card" key={e.id}>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, justifyContent: 'space-between' }}>
                      <h3>
                        {e.role} · {e.organization}
                      </h3>
                      <span className={`pill ${t.tone}`}>{t.label}</span>
                    </div>
                    {e.start_date || e.end_date ? (
                      <p className="sub">
                        {fmtDate(e.start_date)}
                        {e.start_date ? ' to ' : ''}
                        {e.end_date ? fmtDate(e.end_date) : e.start_date ? 'present' : ''}
                      </p>
                    ) : null}
                    {e.description ? <p className="sum">{e.description}</p> : null}
                    {e.skills?.length ? (
                      <div className="tags">
                        {e.skills.map((s: string) => (
                          <span className="tag" key={s}>
                            {s}
                          </span>
                        ))}
                      </div>
                    ) : null}
                    <div className="row">
                      <ExtLink href={safeUrl(e.proof_url)}>
                        <Icon name="ext" />
                        Proof
                      </ExtLink>
                    </div>
                  </article>
                );
              })}
            </div>
          ) : (
            <Empty
              title="No experience published yet"
              text="Applications, selections and completed internships are listed separately, each with its own status."
            />
          )}
        </Section>

        <Section id="achievements" title="Achievements, awards and events">
          {achs.length ? (
            <div className="grid">
              {achs.map((a: Row) => {
                const file = a.file_path ? urls[a.file_path] : undefined;
                return (
                  <article className="card" key={a.id}>
                    <p className="sub">
                      {a.event || ''}
                      {a.achieved_on ? `${a.event ? ' · ' : ''}${fmtDate(a.achieved_on)}` : ''}
                    </p>
                    <h3>{a.title}</h3>
                    {a.description ? <p className="sum">{a.description}</p> : null}
                    <div className="row">
                      <ExtLink href={file ?? null}>
                        <Icon name="eye" />
                        Proof
                      </ExtLink>
                      <ExtLink href={safeUrl(a.link_url)}>
                        <Icon name="ext" />
                        Link
                      </ExtLink>
                    </div>
                  </article>
                );
              })}
            </div>
          ) : (
            <Empty title="No achievements published yet" text="Awards and events appear here once they are published." />
          )}
        </Section>

        <Section id="education" title="Education">
          <div className="card">
            <h3>B.Tech Artificial Intelligence and Data Science</h3>
            <p className="sum">Thamirabharani Engineering College, Tirunelveli</p>
          </div>
        </Section>

        <Section id="resume" title="Resume">
          {resumeUrl ? (
            <div className="card">
              <p className="sum">Current resume{resume?.file_name ? `: ${resume.file_name}` : ''}</p>
              <div className="row">
                <a className="btn primary" href={resumeUrl} target="_blank" rel="noopener noreferrer">
                  <Icon name="down" />
                  Download Resume
                </a>
              </div>
            </div>
          ) : (
            <Empty title="Resume not available yet" text="The resume will be available here once it is published." />
          )}
        </Section>

        <Section id="contact" title="Contact" intro="The fastest way to reach me is through LinkedIn.">
          <div className="contact-links">
            <a className="btn primary" href={linkedin} target="_blank" rel="noopener noreferrer">
              <Icon name="li" />
              Message on LinkedIn
            </a>
            <a className="btn" href={github} target="_blank" rel="noopener noreferrer">
              <Icon name="gh" />
              GitHub profile
            </a>
          </div>
          {profile.email ? (
            <p className="sum" style={{ marginTop: 16, color: 'var(--fg2)' }}>
              Email: <span style={{ color: 'var(--fg)', userSelect: 'all' }}>{profile.email}</span>
            </p>
          ) : null}
        </Section>
      </main>

      <footer className="foot">
        <div className="wrap">
          <span>© {new Date().getFullYear()} Subaithal S. · Built with CertiFolio AI</span>
          <nav aria-label="Social links">
            <a href={linkedin} target="_blank" rel="noopener noreferrer">
              LinkedIn
            </a>
            <a href={github} target="_blank" rel="noopener noreferrer">
              GitHub
            </a>
          </nav>
        </div>
      </footer>
    </>
  );
}
