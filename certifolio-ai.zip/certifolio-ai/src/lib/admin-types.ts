import type { ReactNode } from 'react';

export type Row = Record<string, any>;

export type FieldType =
  | 'text'
  | 'email'
  | 'url'
  | 'date'
  | 'textarea'
  | 'select'
  | 'tags'
  | 'checkbox'
  | 'file'
  | 'files'
  | 'multiref'
  | 'custom';

export interface Field {
  name: string;
  label: string;
  type: FieldType;
  required?: boolean;
  hint?: string;
  full?: boolean;
  placeholder?: string;
  hidden?: boolean; // saved with the record but drawn by renderExtra
  options?: (string | { value: string; label: string })[];
  // file fields
  mimes?: string[];
  maxMB?: number;
  nameCol?: string;
  sizeCol?: string;
  // multiref fields
  table?: string;
  labelCol?: string;
}

export interface ResourceConfig {
  table: string;
  title: string;
  singular: string;
  folder?: string;
  titleField: string;
  publishField: string;
  publishLabels?: [string, string]; // [on, off]
  fields: Field[];
  emptyHint: string;
  intro?: string;
  slugFrom?: string;
  subtitle?: (r: Row) => string;
  searchText?: (r: Row) => string;
  // Use get for one value per row, or getAll when a row can have several (for example skills).
  filters?: { label: string; get?: (r: Row) => string; getAll?: (r: Row) => string[] }[];
  duplicateCheck?: (rows: Row[], values: Row, newFile: File | null) => string | null;
  previewHref?: (r: Row) => string | null;
  renderExtra?: (ctx: { values: Row; set: (patch: Row) => void; rows: Row[] }) => ReactNode;
}
