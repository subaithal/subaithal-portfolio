import { createClient, type SupabaseClient } from '@supabase/supabase-js';

/**
 * Anonymous read-only client used by the public pages.
 * Returns null when the environment variables are missing, so the site can show
 * a setup message instead of crashing during the first deploy.
 */
export function publicClient(): SupabaseClient | null {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) return null;
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}
