# CertiFolio AI

A personal portfolio website with a private admin dashboard, for Subaithal S.

- Public site: hero with your photo, About, Skills, Certificates, Projects (with detail pages), Experience, Achievements, Education, Resume, Contact.
- Admin dashboard at `/admin`: sign in from your phone, then add, edit, publish, unpublish and delete everything without touching code.
- Built with Next.js 14, TypeScript, Tailwind CSS and Supabase (database, file storage, login).

## Read this first: what is and is not verified

The code was written and checked in an environment that could not download npm packages, so **`npm install` and `npm run build` have not been run on this exact code**. Here is what was verified and what was not.

Verified:
- TypeScript type check against stand-in type declarations: no errors. This catches typos and wrong variable names, but not every mismatch with the real Next.js and Supabase types.
- Helper logic (slug, URL safety, file checks, skill suggestions): unit-checked.
- `supabase/schema.sql`: run twice on a real PostgreSQL server with stand-ins for Supabase's `auth` and `storage` schemas. It runs without errors and is safe to re-run.
- Security policies, tested as three roles: a visitor sees only published records and only the files that published records use; a signed-in non-admin cannot write; an admin can do everything. Only one resume can be published at a time.

Not verified:
- `npm install`, `npm run build` and `npm run dev` on this code.
- Anything against a live Supabase project: sign-in, uploads, signed file links, and the admin pages in a browser.
- Layout on a real phone.

If the first build prints an error, copy the error text and send it to Claude. It is usually a one-line fix.

## Steps you must do yourself

You need free accounts on Supabase, GitHub and Vercel. Nothing here needs a credit card on the free plans.

### Part A. Supabase (database, files, login)

1. Go to supabase.com, sign in, choose **New project**. Pick a name, a strong database password (save it somewhere safe) and the region closest to you.
2. When the project is ready, open **SQL Editor**, choose **New query**, paste the whole contents of `supabase/schema.sql`, and press **Run**. It creates the tables, security rules, the private file bucket and four draft starter projects.
3. Open **Authentication**, then **Users**, then **Add user**. Enter your email and a strong password. Tick the option to auto-confirm the email if it is shown.
4. Back in **SQL Editor**, run this with your own email to make yourself the administrator:

   ```sql
   insert into public.admins (user_id)
   select id from auth.users where email = 'you@example.com';
   ```

5. Turn off public sign-ups so nobody else can create accounts: **Authentication**, **Sign In / Providers** (or **Providers**), **Email**, and switch off **Allow new users to sign up**. Menu names change over time, so look for the sign-up toggle if the wording differs. Even if sign-ups stay on, strangers cannot write, because only accounts listed in the `admins` table are allowed. Turning it off is still the safer setting.
6. Open **Project Settings**, then **API**. Copy the **Project URL** and the **anon public** key. You need them in Part C. Do not use the `service_role` key anywhere in this project.

### Part B. Run it on your computer (optional)

You need Node.js 18.17 or newer.

```bash
npm install
cp .env.example .env.local      # then edit .env.local and paste your two values
npm run dev
```

Open http://localhost:3000 for the site and http://localhost:3000/login for the admin.

### Part C. Put the code on GitHub

Never commit `.env.local`. The included `.gitignore` already excludes it.

Using the command line, from the project folder:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/certifolio-ai.git
git push -u origin main
```

Create the empty repository first on github.com (**New repository**, no README, no .gitignore). Without a command line, you can instead choose **Add file**, **Upload files** on the new repository page and drag the unzipped project files in (not the `node_modules` folder, which is not included anyway).

Your GitHub username appears in two spellings in your notes (`Subaithals` and `subaithal`). Check which is correct and use that one in the remote URL above.

### Part D. Deploy on Vercel

1. Go to vercel.com and sign in with GitHub.
2. Choose **Add New**, **Project**, then import the `certifolio-ai` repository.
3. Before pressing Deploy, open **Environment Variables** and add:
   - `NEXT_PUBLIC_SUPABASE_URL` = your Project URL
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY` = your anon public key
   - `NEXT_PUBLIC_SITE_URL` = the address Vercel gives you (you can add it after the first deploy and redeploy)
4. Press **Deploy**. When it finishes, you get a public address like `https://certifolio-ai.vercel.app`. That is the link to share with recruiters.
5. If you add or change environment variables later, go to **Deployments**, open the latest one and choose **Redeploy**.

The anon key is meant to be public. Row Level Security in the database is what protects your data.

### Part E. First use

1. Open `your-site.vercel.app/login` and sign in.
2. **Profile**: upload your own photo, write your About text, check your LinkedIn and GitHub links, save.
3. **Resume**: upload your PDF, then press Publish.
4. **Projects**: open each starter project, add a real summary, the technologies you actually used and your own screenshots, then publish it. Starter projects begin as drafts, so nothing half-finished appears publicly.
5. **Certificates**: add a certificate, type or paste its text, press Suggest skills, approve or reject each suggestion, add your own, then save and publish.
6. **Skills, Experience, Achievements**: add only what is true. Experience entries have a status, so an application is never shown as a finished internship.

Changes show on the public site within about a minute.

### Part F. Custom domain (optional)

In Vercel open the project, then **Settings**, **Domains**, and add your domain. Vercel shows the DNS records to create at your domain provider. Domains are bought separately and cost money. The `vercel.app` address is free.

## Limits and costs

These are the free-plan figures as I know them. Plans change, so confirm on supabase.com/pricing and vercel.com/pricing.

- Supabase free plan: about 1 GB of file storage, about 500 MB of database, and a per-file limit that this project caps at 10 MB (5 MB for the resume and photo). Free projects may be paused after a period without activity, and you restart them from the dashboard. If the site shows a database error after a quiet spell, check for a paused project.
- Vercel Hobby plan: free for personal, non-commercial use, with usage limits. A portfolio is well within them.
- Video: upload videos to YouTube or Google Drive and paste the link. Large video files do not fit comfortably in the free storage.
- Storage is not unlimited. The Overview page shows how much you have used.

## Backups

- Overview, then **Download backup (JSON)** saves all your records. It does not include the uploaded files, so keep the original PDFs and images on your phone or drive.
- Supabase also offers backup options on paid plans. On the free plan, treat the JSON export plus your original files as your backup, and export after big changes.

## How security works

- `/admin` is blocked on the server by `middleware.ts`: no valid session, or not listed in the `admins` table, means a redirect to `/login`.
- The database enforces the same rule with Row Level Security. Visitors can read only published rows. Only admins can write. Hiding a button is never relied upon.
- Files live in one private bucket. A visitor can fetch a file only when a published record points to it. Public pages receive short-lived signed links.
- Uploads are limited to PDF, PNG, JPG and WebP, and checked for type and size in the browser and again by the bucket's own limits.
- Links saved in the database are rendered only if they start with http or https.
- No secret keys are in the code. Only the two public values go in environment variables.

## OCR and skill suggestions

Reading text out of a certificate image automatically needs an OCR or AI service, which usually means an API key and costs. It is not built in. Instead:

1. You type or paste the text printed on the certificate.
2. The app matches it against a fixed list of skill names and suggests matches.
3. You approve or reject each one and can add your own.

Only approved skills are saved on the certificate and shown publicly. A certificate never adds a skill by itself. Adding real OCR later is a separate change.

## LinkedIn

The site does not post to LinkedIn. The project editor drafts a caption from your own project details. Copy it, post it on LinkedIn yourself, then paste the post's address into the project so it appears on the project page.

## Troubleshooting

- **Site shows "Almost there: connect Supabase"**: the two environment variables are missing or wrong in Vercel. Fix them and redeploy.
- **Cannot sign in**: check the email and password in Supabase **Authentication**, **Users**, and confirm you ran the `insert into public.admins` step with the same email.
- **Signed in but sent back to the login page with a notice**: the account is not in the `admins` table.
- **Upload fails**: the file must be PDF, PNG, JPG or WebP and under the size limit. Check your connection and try again. A failed save removes the files it just uploaded.
- **Published item does not appear**: the public page refreshes about once a minute. Wait a moment and reload.
- **Build fails on Vercel**: open the failed deployment, copy the red error text, and send it to Claude.

## Project layout

```
supabase/schema.sql        tables, security rules, storage bucket, starter projects
middleware.ts              server-side gate for /admin
src/app/page.tsx           public homepage
src/app/projects/[slug]    project detail pages
src/app/login              admin sign-in
src/app/admin/*            dashboard pages
src/components/admin/      shared admin pieces (list/form manager, skill review, caption tools)
src/lib/                   Supabase clients, upload helper, utilities
```
