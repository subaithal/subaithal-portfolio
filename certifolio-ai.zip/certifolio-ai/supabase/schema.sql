-- CertiFolio AI database schema
-- Run this whole file once in Supabase: SQL Editor > New query > paste > Run.
-- It is safe to run again; objects that already exist are skipped.

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------
-- 1. Admin list and the is_admin() check used by every policy
-- ---------------------------------------------------------------
create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);
alter table public.admins enable row level security;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (select 1 from public.admins where user_id = auth.uid());
$$;

drop policy if exists "admins read own row" on public.admins;
create policy "admins read own row" on public.admins
  for select to authenticated using (user_id = auth.uid());

-- ---------------------------------------------------------------
-- 2. Content tables
-- ---------------------------------------------------------------
create table if not exists public.site_profile (
  id int primary key default 1 check (id = 1),
  bio text,
  email text,
  linkedin text,
  github text,
  photo_path text,
  updated_at timestamptz not null default now()
);

create table if not exists public.skills (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null,
  stage text not null,
  description text,
  cert_ids uuid[] not null default '{}',
  project_ids uuid[] not null default '{}',
  is_public boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.certificates (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  issuer text not null,
  issue_date date,
  credential_id text,
  verify_url text,
  description text,
  category text,
  tags text[] not null default '{}',
  skills text[] not null default '{}',   -- approved skills only
  file_path text,
  file_name text,
  file_size bigint,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  title text not null,
  summary text,
  problem text,
  solution text,
  tech text[] not null default '{}',
  images text[] not null default '{}',
  video_url text,
  live_url text,
  repo_url text,
  project_status text,
  category text,
  tags text[] not null default '{}',
  dev_details text,
  linkedin_caption text,
  linkedin_post_url text,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.experiences (
  id uuid primary key default gen_random_uuid(),
  organization text not null,
  role text not null,
  entry_type text not null default 'applied'
    check (entry_type in ('applied','shortlisted','selected','ongoing','completed')),
  start_date date,
  end_date date,
  description text,
  skills text[] not null default '{}',
  proof_url text,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.achievements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  event text,
  achieved_on date,
  description text,
  link_url text,
  file_path text,
  file_name text,
  file_size bigint,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.resumes (
  id uuid primary key default gen_random_uuid(),
  file_path text not null,
  file_name text,
  file_size bigint,
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);
-- Only one resume can be published at a time.
create unique index if not exists resumes_one_published on public.resumes (is_published) where is_published;

-- ---------------------------------------------------------------
-- 3. Row Level Security: public reads published rows, admins do everything
-- ---------------------------------------------------------------
alter table public.site_profile  enable row level security;
alter table public.skills        enable row level security;
alter table public.certificates  enable row level security;
alter table public.projects      enable row level security;
alter table public.experiences   enable row level security;
alter table public.achievements  enable row level security;
alter table public.resumes       enable row level security;

drop policy if exists "public read profile" on public.site_profile;
create policy "public read profile" on public.site_profile for select to anon, authenticated using (true);
drop policy if exists "admin write profile" on public.site_profile;
create policy "admin write profile" on public.site_profile for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "public read skills" on public.skills;
create policy "public read skills" on public.skills for select to anon, authenticated using (is_public);
drop policy if exists "admin all skills" on public.skills;
create policy "admin all skills" on public.skills for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "public read certificates" on public.certificates;
create policy "public read certificates" on public.certificates for select to anon, authenticated using (published);
drop policy if exists "admin all certificates" on public.certificates;
create policy "admin all certificates" on public.certificates for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "public read projects" on public.projects;
create policy "public read projects" on public.projects for select to anon, authenticated using (published);
drop policy if exists "admin all projects" on public.projects;
create policy "admin all projects" on public.projects for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "public read experiences" on public.experiences;
create policy "public read experiences" on public.experiences for select to anon, authenticated using (published);
drop policy if exists "admin all experiences" on public.experiences;
create policy "admin all experiences" on public.experiences for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "public read achievements" on public.achievements;
create policy "public read achievements" on public.achievements for select to anon, authenticated using (published);
drop policy if exists "admin all achievements" on public.achievements;
create policy "admin all achievements" on public.achievements for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "public read resumes" on public.resumes;
create policy "public read resumes" on public.resumes for select to anon, authenticated using (is_published);
drop policy if exists "admin all resumes" on public.resumes;
create policy "admin all resumes" on public.resumes for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- ---------------------------------------------------------------
-- 4. File storage: one private bucket, 10 MB per file, PDF and images only
-- ---------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'portfolio-files', 'portfolio-files', false, 10485760,
  array['application/pdf', 'image/png', 'image/jpeg', 'image/webp']
)
on conflict (id) do update
  set file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types,
      public = false;

drop policy if exists "admin manage files" on storage.objects;
create policy "admin manage files" on storage.objects for all to authenticated
  using (bucket_id = 'portfolio-files' and public.is_admin())
  with check (bucket_id = 'portfolio-files' and public.is_admin());

-- Visitors can only fetch a file if a PUBLISHED record points to it.
-- Drafts and unpublished resumes stay private.
drop policy if exists "public read published files" on storage.objects;
create policy "public read published files" on storage.objects for select to anon, authenticated
using (
  bucket_id = 'portfolio-files' and (
    exists (select 1 from public.certificates c where c.published and c.file_path = storage.objects.name)
    or exists (select 1 from public.projects p where p.published and storage.objects.name = any (p.images))
    or exists (select 1 from public.achievements a where a.published and a.file_path = storage.objects.name)
    or exists (select 1 from public.resumes r where r.is_published and r.file_path = storage.objects.name)
    or exists (select 1 from public.site_profile s where s.photo_path = storage.objects.name)
  )
);

-- ---------------------------------------------------------------
-- 5. Starter projects (drafts, so nothing half-finished goes public).
--    Open Admin > Projects to add summaries, technologies and screenshots,
--    then publish each one.
-- ---------------------------------------------------------------
insert into public.projects (slug, title, live_url, repo_url, published) values
  ('spendwise-smart', 'SpendWise Smart', 'https://spendwise-smart.vercel.app', null, false),
  ('attendance-recovery-planner', 'Attendance Recovery Planner', 'https://attendance-ten-indol.vercel.app', null, false),
  ('flashlearn', 'FlashLearn', 'https://flashlearn-l36xo296g-subaithal.vercel.app', 'https://github.com/subaithal/CodeAlpha_FlashLearn', false),
  ('linguatranslator', 'LinguaTranslator', 'https://codealpha-lingua-translator.vercel.app', 'https://github.com/subaithal/CodeAlpha_LinguaTranslator', false)
on conflict (slug) do nothing;

insert into public.site_profile (id, linkedin, github)
values (1, 'https://www.linkedin.com/in/subaithal-s-812584426', 'https://github.com/Subaithals')
on conflict (id) do nothing;

-- ---------------------------------------------------------------
-- 6. MAKE YOURSELF THE ADMIN (run this separately, after the steps above)
--    First create your user in Supabase: Authentication > Users > Add user,
--    with your email and a strong password. Then run this with YOUR email:
--
--    insert into public.admins (user_id)
--    select id from auth.users where email = 'you@example.com';
-- ---------------------------------------------------------------
