'use client';

import ResourceManager from '@/components/admin/ResourceManager';
import SkillReview from '@/components/admin/SkillReview';
import type { ResourceConfig } from '@/lib/admin-types';
import { fmtDate } from '@/lib/utils';

const config: ResourceConfig = {
  table: 'certificates',
  title: 'Certificate Vault',
  singular: 'certificate',
  folder: 'certificates',
  titleField: 'title',
  publishField: 'published',
  emptyHint: 'Add a certificate with a PDF, PNG or JPG file. You review its skills before anything goes public.',
  intro: 'Upload certificates, review the suggested skills, then publish. Drafts stay private.',
  fields: [
    { name: 'title', label: 'Certificate title', type: 'text', required: true, full: true },
    { name: 'issuer', label: 'Issuing organization', type: 'text', required: true },
    { name: 'issue_date', label: 'Issue date', type: 'date' },
    { name: 'credential_id', label: 'Credential ID', type: 'text' },
    { name: 'verify_url', label: 'Credential verification URL', type: 'url', placeholder: 'https://' },
    {
      name: 'file_path',
      label: 'Certificate file',
      type: 'file',
      mimes: ['application/pdf', 'image/png', 'image/jpeg'],
      maxMB: 10,
      nameCol: 'file_name',
      sizeCol: 'file_size',
      hint: 'PDF, PNG or JPG, up to 10 MB.',
    },
    {
      name: 'category',
      label: 'Category',
      type: 'select',
      options: ['Artificial Intelligence', 'Data Science', 'Programming', 'Cloud', 'Design', 'Other'],
    },
    { name: 'tags', label: 'Tags', type: 'tags' },
    { name: 'description', label: 'Description', type: 'textarea' },
    { name: 'skills', label: 'Approved skills', type: 'custom', hidden: true },
    { name: 'published', label: 'Show on public site', type: 'checkbox' },
  ],
  subtitle: (r) =>
    [r.issuer, r.issue_date ? fmtDate(r.issue_date) : '', `${(r.skills || []).length} approved skill${(r.skills || []).length === 1 ? '' : 's'}`]
      .filter(Boolean)
      .join(' · '),
  searchText: (r) => `${r.issuer ?? ''} ${(r.tags || []).join(' ')} ${(r.skills || []).join(' ')} ${r.credential_id ?? ''}`,
  filters: [
    { label: 'Issuers', get: (r) => r.issuer ?? '' },
    { label: 'Categories', get: (r) => r.category ?? '' },
    { label: 'Years', get: (r) => (r.issue_date ? String(r.issue_date).slice(0, 4) : '') },
    { label: 'Skills', getAll: (r) => (r.skills as string[]) || [] },
  ],
  duplicateCheck: (rows, v, file) => {
    const dup = rows.find(
      (r) =>
        (v.credential_id && r.credential_id && String(r.credential_id).trim() === String(v.credential_id).trim()) ||
        (file && r.file_name === file.name && Number(r.file_size) === file.size),
    );
    return dup ? `This looks like a duplicate of "${dup.title}" (same credential ID or file).` : null;
  },
  renderExtra: ({ values, set }) => <SkillReview values={values} set={set} />,
};

export default function CertificatesPage() {
  return <ResourceManager config={config} />;
}
