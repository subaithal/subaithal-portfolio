import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Icon from '@/components/Icon';
import SiteNav from '@/components/SiteNav';
import { getProject } from '@/lib/public-data';
import { safeUrl } from '@/lib/utils';

export const revalidate = 60;

type Props = { params: { slug: string } };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const found = await getProject(params.slug);
  if (!found) return { title: 'Project' };
  const { project } = found;
  return {
    title: project.title,
    description: project.summary || `${project.title}, a project by Subaithal S.`,
    openGraph: { title: project.title, description: project.summary || undefined },
  };
}

export default async function ProjectPage({ params }: Props) {
  const found = await getProject(params.slug);
  if (!found) notFound();
  const { project: p, urls } = found;
  const images: string[] = (p.images ?? []).map((path: string) => urls[path]).filter(Boolean);
  const live = safeUrl(p.live_url);
  const repo = safeUrl(p.repo_url);
  const video = safeUrl(p.video_url);
  const post = safeUrl(p.linkedin_post_url);

  return (
    <>
      <SiteNav />
      <main id="main" className="wrap">
        <article className="detail">
          <a className="back" href="/#projects">
            Back to projects
          </a>
          <div>
            <p className="sub">
              Project{p.project_status ? ` · ${p.project_status}` : ''}
              {p.category ? ` · ${p.category}` : ''}
            </p>
            <h1>{p.title}</h1>
          </div>
          {images.length ? (
            <div className="gallery">
              {images.map((src, i) => (
                // eslint-disable-next-line @next/next/no-img-element
                <img key={src} src={src} alt={`${p.title} screenshot ${i + 1}`} loading="lazy" />
              ))}
            </div>
          ) : null}
          {p.summary ? <p className="lede">{p.summary}</p> : <p className="sum">The write-up for this project is coming soon.</p>}
          {p.problem ? (
            <div>
              <p className="sub">Problem</p>
              <p style={{ whiteSpace: 'pre-wrap' }}>{p.problem}</p>
            </div>
          ) : null}
          {p.solution ? (
            <div>
              <p className="sub">Solution and features</p>
              <p style={{ whiteSpace: 'pre-wrap' }}>{p.solution}</p>
            </div>
          ) : null}
          {p.dev_details ? (
            <div>
              <p className="sub">Development details</p>
              <p style={{ whiteSpace: 'pre-wrap' }}>{p.dev_details}</p>
            </div>
          ) : null}
          {p.tech?.length ? (
            <div>
              <p className="sub">Technologies</p>
              <div className="tags">
                {p.tech.map((t: string) => (
                  <span className="tag on" key={t}>
                    {t}
                  </span>
                ))}
              </div>
            </div>
          ) : null}
          <div className="actions">
            {live ? (
              <a className="btn primary" href={live} target="_blank" rel="noopener noreferrer">
                <Icon name="ext" />
                Live demo
              </a>
            ) : null}
            {repo ? (
              <a className="btn" href={repo} target="_blank" rel="noopener noreferrer">
                <Icon name="gh" />
                GitHub
              </a>
            ) : null}
            {video ? (
              <a className="btn" href={video} target="_blank" rel="noopener noreferrer">
                <Icon name="ext" />
                Video
              </a>
            ) : null}
            {post ? (
              <a className="btn" href={post} target="_blank" rel="noopener noreferrer">
                <Icon name="li" />
                LinkedIn post
              </a>
            ) : null}
          </div>
        </article>
      </main>
    </>
  );
}
