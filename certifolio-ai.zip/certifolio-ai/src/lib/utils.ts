export const BUCKET = 'portfolio-files';

export const csv = (s: string): string[] =>
  s
    .split(',')
    .map((x) => x.trim())
    .filter(Boolean);

export function slugify(s: string): string {
  const out = s
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);
  return out || 'project';
}

export function fmtDate(d?: string | null): string {
  if (!d) return '';
  const t = new Date(d);
  return isNaN(t.getTime()) ? '' : t.toLocaleDateString('en-IN', { month: 'short', year: 'numeric' });
}

export function fmtSize(b: number): string {
  if (b >= 1048576) return (b / 1048576).toFixed(1) + ' MB';
  return Math.max(1, Math.round(b / 1024)) + ' KB';
}

export function safeName(n: string): string {
  return n.replace(/[^a-zA-Z0-9._-]+/g, '_').slice(-80);
}

export function randomId(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

/** Returns an error message, or null when the file is acceptable. */
export function checkFile(file: File, mimes: string[], maxMB: number): string | null {
  if (!mimes.includes(file.type)) {
    const names = mimes.map((m) => m.split('/')[1].toUpperCase().replace('JPEG', 'JPG')).join(', ');
    return `${file.name} is not an accepted file type. Choose one of: ${names}.`;
  }
  if (file.size > maxMB * 1048576) {
    return `${file.name} is ${fmtSize(file.size)}. The limit is ${maxMB} MB. Compress it and try again.`;
  }
  if (file.size === 0) return `${file.name} is empty.`;
  return null;
}

/** Only allow http(s) links from the database to be rendered as hrefs. */
export function safeUrl(u?: string | null): string | null {
  if (!u) return null;
  try {
    const x = new URL(u);
    return x.protocol === 'https:' || x.protocol === 'http:' ? x.toString() : null;
  } catch {
    return null;
  }
}
