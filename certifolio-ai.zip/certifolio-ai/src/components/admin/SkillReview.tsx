'use client';

import { useState } from 'react';
import Icon from '@/components/Icon';
import type { Row } from '@/lib/admin-types';
import { suggestSkills } from '@/lib/skills';
import { useToast } from './Toast';

type Suggestion = { name: string; state: 'pending' | 'rejected' };

/**
 * Review step for certificate skills. Only skills in values.skills (the approved list) are saved
 * and shown publicly. Suggestions never become public until you approve them.
 */
export default function SkillReview({ values, set }: { values: Row; set: (patch: Row) => void }) {
  const toast = useToast();
  const [text, setText] = useState('');
  const [suggested, setSuggested] = useState<Suggestion[]>([]);
  const [manual, setManual] = useState('');
  const approved: string[] = values.skills || [];

  function suggest() {
    const found = suggestSkills(text).filter(
      (n) => !approved.some((a) => a.toLowerCase() === n.toLowerCase()) && !suggested.some((s) => s.name === n),
    );
    if (!found.length) toast('No new known skill names found in that text. You can add skills by hand.');
    setSuggested((prev) => [...prev, ...found.map((name) => ({ name, state: 'pending' as const }))]);
  }
  function approve(name: string) {
    set({ skills: [...approved, name] });
    setSuggested((prev) => prev.filter((s) => s.name !== name));
  }
  function reject(name: string) {
    setSuggested((prev) => prev.map((s) => (s.name === name ? { ...s, state: 'rejected' as const } : s)));
  }
  function addManual() {
    const name = manual.trim();
    if (!name) {
      toast('Type a skill name first.', 'bad');
      return;
    }
    if (approved.some((a) => a.toLowerCase() === name.toLowerCase())) {
      toast('That skill is already approved.', 'bad');
      return;
    }
    set({ skills: [...approved, name] });
    setManual('');
  }

  return (
    <div className="panel" style={{ margin: 0 }}>
      <h3>Review skills</h3>
      <p style={{ color: 'var(--fg2)', fontSize: 14, marginBottom: 10 }}>
        Automatic text reading (OCR) needs a paid service and an API key, so it is not built in. Type or paste the text
        printed on the certificate, correct it, then choose Suggest skills. Matching uses a fixed list of skill names.
        Only skills you approve appear on your public page.
      </p>
      <label className="l" htmlFor="ocr_text">
        Text from the certificate
        <textarea id="ocr_text" style={{ minHeight: 120 }} value={text} onChange={(e) => setText(e.target.value)} />
      </label>
      <div className="fact" style={{ justifyContent: 'flex-start' }}>
        <button className="btn sm" type="button" onClick={suggest}>
          Suggest skills from text
        </button>
      </div>

      {suggested.length ? (
        <div style={{ marginTop: 14 }}>
          <p className="sub">Suggestions</p>
          <div className="sug">
            {suggested.map((s) => (
              <span key={s.name} className={`sugi ${s.state}`}>
                <span>{s.name}</span>
                {s.state === 'pending' ? (
                  <>
                    <button className="y" type="button" aria-label={`Approve ${s.name}`} title="Approve" onClick={() => approve(s.name)}>
                      <Icon name="check" />
                    </button>
                    <button className="n" type="button" aria-label={`Reject ${s.name}`} title="Reject" onClick={() => reject(s.name)}>
                      <Icon name="x" />
                    </button>
                  </>
                ) : null}
              </span>
            ))}
          </div>
        </div>
      ) : null}

      <div style={{ marginTop: 14 }}>
        <p className="sub">Approved skills (shown publicly)</p>
        {approved.length ? (
          <div className="sug">
            {approved.map((name) => (
              <span key={name} className="sugi approved">
                <span>{name}</span>
                <button className="n" type="button" aria-label={`Remove ${name}`} title="Remove" onClick={() => set({ skills: approved.filter((a) => a !== name) })}>
                  <Icon name="x" />
                </button>
              </span>
            ))}
          </div>
        ) : (
          <p style={{ color: 'var(--fg2)', fontSize: 14 }}>None yet.</p>
        )}
      </div>

      <div className="tools" style={{ margin: '14px 0 0' }}>
        <label className="sr" htmlFor="manual_skill">
          Add a skill
        </label>
        <input id="manual_skill" style={{ maxWidth: 260 }} placeholder="Add a skill by hand" value={manual} onChange={(e) => setManual(e.target.value)} />
        <button className="btn sm" type="button" onClick={addManual}>
          <Icon name="plus" />
          Add
        </button>
      </div>
    </div>
  );
}
