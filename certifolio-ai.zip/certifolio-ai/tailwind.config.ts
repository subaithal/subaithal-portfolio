import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        midnight: '#070B19',
        indigo2: '#10132B',
        cardbg: '#0D1224',
        electric: '#8B5CF6',
        violet2: '#A855F7',
        magenta2: '#D946EF',
        ink: '#F8FAFC',
        mute: '#AAB1C5',
      },
      fontFamily: {
        display: ['"Bricolage Grotesque"', 'Segoe UI', 'system-ui', 'sans-serif'],
        body: ['"Instrument Sans"', 'Segoe UI', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'Menlo', 'monospace'],
      },
    },
  },
  plugins: [],
};

export default config;
