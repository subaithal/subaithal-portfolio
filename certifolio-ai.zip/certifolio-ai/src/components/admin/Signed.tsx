'use client';

import { useEffect, useState, type ReactNode } from 'react';
import { getBrowserClient } from '@/lib/supabase/client';
import { BUCKET } from '@/lib/utils';

/** Creates a short-lived signed URL for a private file (admin only, enforced by storage policies). */
export function useSignedUrl(path?: string | null): string | null {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    let active = true;
    setUrl(null);
    if (!path) return;
    getBrowserClient()
      .storage.from(BUCKET)
      .createSignedUrl(path, 3600)
      .then(({ data }) => {
        if (active) setUrl(data?.signedUrl ?? null);
      });
    return () => {
      active = false;
    };
  }, [path]);
  return url;
}

export function SignedImage({ path, alt, className }: { path: string; alt: string; className?: string }) {
  const url = useSignedUrl(path);
  if (!url) return <div className={className} style={{ background: 'var(--indigo)' }} aria-label="Loading image" />;
  // eslint-disable-next-line @next/next/no-img-element
  return <img className={className} src={url} alt={alt} loading="lazy" />;
}

export function FileLink({ path, children }: { path?: string | null; children: ReactNode }) {
  const url = useSignedUrl(path);
  if (!path) return null;
  if (!url) return <span className="btn sm ghost" aria-busy="true">Loading</span>;
  return (
    <a className="btn sm" href={url} target="_blank" rel="noopener noreferrer">
      {children}
    </a>
  );
}
