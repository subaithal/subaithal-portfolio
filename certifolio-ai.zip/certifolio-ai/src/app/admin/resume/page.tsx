'use client';

import { useCallback, useEffect, useState } from 'react';
import Icon from '@/components/Icon';
import { FileLink } from '@/components/admin/Signed';
import { useToast } from '@/components/admin/Toast';
import { getBrowserClient } from '@/lib/supabase/client';
import { removeFiles, uploadFile } from '@/lib/upload';
import { checkFile, fmtSize } from '@/lib/utils';
import type { Row } from '@/lib/admin-types';

export default function ResumePage() {
  const supabase = getBrowserClient();
  const toast = useToast();
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [progress, setProgress] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error: err } = await supabase.from('resumes').select('*').order('created_at', { ascending: false });
    if (err) setError(err.message);
    else {
      setError('');
      setRows((data as Row[]) ?? []);
    }
    setLoading(false);
  }, [supabase]);

  useEffect(() => {
    load();
  }, [load]);

  async function onUpload(files: FileList | null) {
    const file = files?.[0];
    if (!file) return;
    const problem = checkFile(file, ['application/pdf'], 5);
    if (problem) {
      toast(problem, 'bad');
      return;
    }
    setBusy(true);
    let path = '';
    try {
      setProgress(0);
      path = await uploadFile(file, 'resumes', setProgress);
      const { error: err } = await supabase
        .from('resumes')
        .insert({ file_path: path, file_name: file.name, file_size: file.size, is_published: false });
      if (err) throw new Error(err.message);
      toast('Resume uploaded. Publish it when you are ready.', 'good');
      await load();
    } catch (e: any) {
      if (path) await removeFiles([path]);
      toast(e?.message ? `Could not upload: ${e.message}` : 'Could not upload. Try again.', 'bad');
    } finally {
      setBusy(false);
      setProgress(null);
    }
  }

  async function publish(row: Row) {
    setBusy(true);
    // Only one resume may be published, so unpublish the others first.
    const off = await supabase.from('resumes').update({ is_published: false }).eq('is_published', true);
    if (off.error) {
      toast(`Could not update: ${off.error.message}`, 'bad');
      setBusy(false);
      return;
    }
    const on = await supabase.from('resumes').update({ is_published: true }).eq('id', row.id);
    setBusy(false);
    if (on.error) {
      toast(`Could not publish: ${on.error.message}`, 'bad');
      load();
      return;
    }
    toast('Published. The public Download Resume button now uses this file.', 'good');
    load();
  }

  async function unpublish(row: Row) {
    const { error: err } = await supabase.from('resumes').update({ is_published: false }).eq('id', row.id);
    if (err) {
      toast(`Could not update: ${err.message}`, 'bad');
      return;
    }
    toast('Unpublished. The public button is hidden.', 'good');
    load();
  }

  async function remove(row: Row) {
    const { error: err } = await supabase.from('resumes').delete().eq('id', row.id);
    if (err) {
      toast(`Could not delete: ${err.message}`, 'bad');
      return;
    }
    await removeFiles([row.file_path]);
    toast('Deleted.', 'good');
    load();
  }

  return (
    <>
      <div className="ahead">
        <h2>Resume</h2>
      </div>
      <div className="panel">
        <h3>Upload a new version</h3>
        <label className="l" htmlFor="resume_file">
          PDF file
          <input id="resume_file" type="file" accept="application/pdf" disabled={busy} onChange={(e) => { onUpload(e.target.files); e.target.value = ''; }} />
          <small>PDF only, up to 5 MB. New uploads start as private. Older versions stay private until you publish one.</small>
        </label>
        {progress !== null ? (
          <div role="status" aria-live="polite">
            <div className="meter">
              <i style={{ width: `${progress}%` }} />
            </div>
            <small style={{ color: 'var(--fg2)' }}>Uploading {progress}%</small>
          </div>
        ) : null}
      </div>

      {loading ? (
        <p style={{ color: 'var(--fg2)' }} role="status">
          Loading...
        </p>
      ) : error ? (
        <div className="alert" role="alert">
          Could not load resumes: {error}{' '}
          <button className="btn sm" type="button" onClick={load}>
            Try again
          </button>
        </div>
      ) : !rows.length ? (
        <div className="empty">
          <b>No resume uploaded yet</b>
          <span>Upload a PDF above, then publish it to show the Download Resume button.</span>
        </div>
      ) : (
        <div className="rows">
          {rows.map((r) => (
            <div className="rowi" key={r.id}>
              <div className="t">
                <b>{r.file_name || 'Resume.pdf'}</b>
                <span>
                  {r.file_size ? fmtSize(Number(r.file_size)) : ''} · uploaded {new Date(r.created_at).toLocaleDateString('en-IN')}
                </span>
              </div>
              <span className={`pill ${r.is_published ? 'ok' : 'mute'}`}>{r.is_published ? 'Published' : 'Private'}</span>
              <div className="ac">
                <FileLink path={r.file_path}>
                  <Icon name="eye" />
                  Preview
                </FileLink>
                {r.is_published ? (
                  <button className="btn sm" type="button" onClick={() => unpublish(r)} disabled={busy}>
                    Unpublish
                  </button>
                ) : (
                  <button className="btn sm primary" type="button" onClick={() => publish(r)} disabled={busy}>
                    Publish
                  </button>
                )}
                <button className="btn sm danger" type="button" aria-label={`Delete ${r.file_name || 'resume'}`} onClick={() => remove(r)} disabled={busy}>
                  <Icon name="trash" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  );
}
