'use client';

import { useState, type ReactNode } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { getBrowserClient } from '@/lib/supabase/client';
import { ToastProvider } from './Toast';

const TABS: [string, string][] = [
  ['/admin', 'Overview'],
  ['/admin/certificates', 'Certificates'],
  ['/admin/projects', 'Projects'],
  ['/admin/experience', 'Experience'],
  ['/admin/achievements', 'Achievements'],
  ['/admin/skills', 'Skills'],
  ['/admin/resume', 'Resume'],
  ['/admin/profile', 'Profile'],
];

export default function AdminShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const [busy, setBusy] = useState(false);

  async function signOut() {
    setBusy(true);
    try {
      await getBrowserClient().auth.signOut();
    } finally {
      window.location.assign('/login');
    }
  }

  return (
    <ToastProvider>
      <header className="topbar">
        <div className="wrap">
          <Link className="brand" href="/admin">
            <i />
            CertiFolio <span>Admin</span>
          </Link>
          <span style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>
            <a className="btn sm ghost" href="/" target="_blank" rel="noopener noreferrer">
              View site
            </a>
            <button className="btn sm" type="button" onClick={signOut} disabled={busy}>
              Sign out
            </button>
          </span>
        </div>
      </header>
      <main id="main" className="wrap">
        <div className="adm">
          <nav className="side" aria-label="Admin sections">
            {TABS.map(([href, label]) => (
              <Link key={href} href={href} aria-current={pathname === href ? 'page' : undefined}>
                {label}
              </Link>
            ))}
          </nav>
          <div>{children}</div>
        </div>
      </main>
    </ToastProvider>
  );
}
