import type { Metadata, Viewport } from 'next';
import './globals.css';

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: 'Subaithal S. | AI and Data Science Portfolio',
    template: '%s | Subaithal S.',
  },
  description:
    'Portfolio of Subaithal S., B.Tech Artificial Intelligence and Data Science student at Thamirabharani Engineering College, Tirunelveli. Projects, certificates and experience.',
  openGraph: {
    type: 'website',
    title: 'Subaithal S. | AI and Data Science Portfolio',
    description: 'Projects, certificates and experience in Artificial Intelligence and Data Science.',
    siteName: 'CertiFolio AI',
  },
  twitter: { card: 'summary', title: 'Subaithal S. | AI and Data Science Portfolio' },
};

export const viewport: Viewport = {
  themeColor: '#070B19',
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700&family=Instrument+Sans:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap"
        />
      </head>
      <body>
        <a className="skip" href="#main">
          Skip to content
        </a>
        {children}
      </body>
    </html>
  );
}
