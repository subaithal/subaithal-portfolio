'use client';

import Icon from '@/components/Icon';
import { csv } from '@/lib/utils';
import type { Row } from '@/lib/admin-types';
import { useToast } from './Toast';

function buildCaption(v: Row): string {
  const tech = csv(String(v.tech || ''));
  const tags = csv(String(v.tags || ''));
  const lines: string[] = [];
  lines.push(`I built ${v.title || 'a new project'}${v.summary ? `: ${v.summary}` : '.'}`);
  if (v.problem) lines.push('', `The problem: ${v.problem}`);
  if (v.solution) lines.push('', `What it does: ${v.solution}`);
  if (tech.length) lines.push('', `Built with: ${tech.join(', ')}`);
  if (v.live_url) lines.push('', `Try it: ${v.live_url}`);
  if (v.repo_url) lines.push(`Code: ${v.repo_url}`);
  lines.push('', 'Feedback is welcome.');
  const hashtags = tags
    .map((t) => '#' + t.replace(/[^A-Za-z0-9]/g, ''))
    .filter((t) => t.length > 1)
    .join(' ');
  if (hashtags) lines.push('', hashtags);
  return lines.join('\n');
}

/**
 * Caption drafting for LinkedIn. Posting stays manual: copy the caption, post it on LinkedIn,
 * then paste the post link below so it shows on the project page.
 */
export default function CaptionTools({ values, set }: { values: Row; set: (patch: Row) => void }) {
  const toast = useToast();

  async function copy() {
    const text = String(values.linkedin_caption || '');
    if (!text) {
      toast('Generate or write a caption first.', 'bad');
      return;
    }
    try {
      await navigator.clipboard.writeText(text);
      toast('Caption copied.', 'good');
    } catch {
      const area = document.getElementById('f_linkedin_caption') as HTMLTextAreaElement | null;
      if (area) {
        area.focus();
        area.select();
      }
      toast('Copy was blocked. The text is selected, press Ctrl+C or use the copy option on your phone.');
    }
  }

  return (
    <div className="panel" style={{ margin: 0 }}>
      <h3>LinkedIn caption</h3>
      <p style={{ color: 'var(--fg2)', fontSize: 14, marginBottom: 10 }}>
        The caption is built only from the details above. This site does not post to LinkedIn. Copy the caption, post it
        yourself, then paste the post link below.
      </p>
      <label className="l" htmlFor="f_linkedin_caption">
        Caption
        <textarea
          id="f_linkedin_caption"
          style={{ minHeight: 190 }}
          value={values.linkedin_caption ?? ''}
          onChange={(e) => set({ linkedin_caption: e.target.value })}
        />
      </label>
      <div className="fact" style={{ justifyContent: 'flex-start' }}>
        <button
          className="btn sm"
          type="button"
          onClick={() => {
            set({ linkedin_caption: buildCaption(values) });
            toast('Caption generated. Edit it as you like.');
          }}
        >
          Generate from details
        </button>
        <button className="btn sm" type="button" onClick={copy}>
          <Icon name="copy" />
          Copy caption
        </button>
      </div>
      <label className="l" htmlFor="f_linkedin_post_url" style={{ marginTop: 12 }}>
        Published LinkedIn post URL
        <input
          id="f_linkedin_post_url"
          type="url"
          placeholder="Paste after you have posted"
          value={values.linkedin_post_url ?? ''}
          onChange={(e) => set({ linkedin_post_url: e.target.value })}
        />
      </label>
    </div>
  );
}
