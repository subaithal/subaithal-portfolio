'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import Icon from '@/components/Icon';
import { getBrowserClient } from '@/lib/supabase/client';
import { removeFiles, uploadFile } from '@/lib/upload';
import { checkFile, csv, fmtSize, randomId, slugify } from '@/lib/utils';
import type { Field, ResourceConfig, Row } from '@/lib/admin-types';
import { FileLink, SignedImage } from './Signed';
import { useToast } from './Toast';

type Editing = { id: string | null; values: Row };

function optValue(o: string | { value: string; label: string }) {
  return typeof o === 'string' ? o : o.value;
}
function optLabel(o: string | { value: string; label: string }) {
  return typeof o === 'string' ? o : o.label;
}

function initialValues(fields: Field[], row?: Row): Row {
  const v: Row = {};
  fields.forEach((f) => {
    const cur = row ? row[f.name] : undefined;
    if (f.type === 'tags') v[f.name] = Array.isArray(cur) ? cur.join(', ') : '';
    else if (f.type === 'checkbox') v[f.name] = Boolean(cur);
    else if (f.type === 'files' || f.type === 'multiref' || f.type === 'custom') v[f.name] = Array.isArray(cur) ? [...cur] : [];
    else if (f.type === 'select' && f.required && !cur && f.options && f.options.length) v[f.name] = optValue(f.options[0]);
    else v[f.name] = cur ?? '';
  });
  return v;
}

export default function ResourceManager({ config }: { config: ResourceConfig }) {
  const supabase = getBrowserClient();
  const toast = useToast();

  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [query, setQuery] = useState('');
  const [filterVals, setFilterVals] = useState<Record<string, string>>({});
  const [sort, setSort] = useState('new');
  const [editing, setEditing] = useState<Editing | null>(null);
  const [pending, setPending] = useState<Record<string, File[]>>({});
  const [fieldErr, setFieldErr] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [progress, setProgress] = useState<number | null>(null);
  const [dupMsg, setDupMsg] = useState('');
  const [confirmRow, setConfirmRow] = useState<Row | null>(null);
  const [refs, setRefs] = useState<Record<string, { id: string; label: string }[]>>({});

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from(config.table).select('*').order('created_at', { ascending: false });
    if (error) {
      setLoadError(error.message);
    } else {
      setLoadError('');
      setRows((data as Row[]) ?? []);
    }
    setLoading(false);
  }, [supabase, config.table]);

  useEffect(() => {
    load();
  }, [load]);

  // Load option lists for multiref fields when a form opens.
  useEffect(() => {
    if (!editing) return;
    config.fields
      .filter((f) => f.type === 'multiref' && f.table && f.labelCol)
      .forEach(async (f) => {
        const { data } = await (supabase.from(f.table as string) as any).select(`id,${f.labelCol}`);
        const list = ((data as Row[]) ?? []).map((r) => ({ id: String(r.id), label: String(r[f.labelCol as string] ?? '') }));
        setRefs((prev) => ({ ...prev, [f.name]: list }));
      });
  }, [editing === null, supabase, config.fields]); // eslint-disable-line react-hooks/exhaustive-deps

  function openNew() {
    setEditing({ id: null, values: initialValues(config.fields) });
    setPending({});
    setFieldErr({});
    setDupMsg('');
  }
  function openEdit(row: Row) {
    setEditing({ id: row.id, values: initialValues(config.fields, row) });
    setPending({});
    setFieldErr({});
    setDupMsg('');
  }
  function closeForm() {
    setEditing(null);
    setPending({});
    setFieldErr({});
    setDupMsg('');
  }
  function setValue(name: string, value: any) {
    setEditing((e) => (e ? { ...e, values: { ...e.values, [name]: value } } : e));
  }
  function patchValues(patch: Row) {
    setEditing((e) => (e ? { ...e, values: { ...e.values, ...patch } } : e));
  }

  function onFiles(f: Field, files: FileList | null) {
    if (!files || !files.length) return;
    const list = Array.from(files);
    const errors: string[] = [];
    const good: File[] = [];
    list.forEach((file) => {
      const err = checkFile(file, f.mimes ?? [], f.maxMB ?? 10);
      if (err) errors.push(err);
      else good.push(file);
    });
    setFieldErr((prev) => ({ ...prev, [f.name]: errors.join(' ') }));
    if (good.length) {
      setPending((prev) => ({
        ...prev,
        [f.name]: f.type === 'files' ? [...(prev[f.name] ?? []), ...good] : [good[0]],
      }));
      setDupMsg('');
    }
  }

  async function save(force = false) {
    if (!editing) return;
    const v = editing.values;
    const errs: Record<string, string> = {};
    config.fields.forEach((f) => {
      if (f.required && !String(v[f.name] ?? '').trim()) errs[f.name] = `${f.label} is required.`;
    });
    setFieldErr(errs);
    if (Object.keys(errs).length) {
      toast('Fill in the highlighted fields.', 'bad');
      return;
    }

    if (!force && !editing.id && config.duplicateCheck) {
      const firstFile = Object.values(pending)[0]?.[0] ?? null;
      const msg = config.duplicateCheck(rows, v, firstFile);
      if (msg) {
        setDupMsg(msg);
        return;
      }
    }

    setSaving(true);
    setDupMsg('');
    const uploaded: string[] = [];
    const old: string[] = [];
    try {
      const existing = editing.id ? rows.find((r) => r.id === editing.id) : undefined;
      const payload: Row = {};

      for (const f of config.fields) {
        const val = v[f.name];
        if (f.type === 'tags') {
          payload[f.name] = csv(String(val || ''));
        } else if (f.type === 'checkbox') {
          payload[f.name] = Boolean(val);
        } else if (f.type === 'file') {
          const newFile = pending[f.name]?.[0];
          if (newFile) {
            setProgress(0);
            const path = await uploadFile(newFile, config.folder || config.table, setProgress);
            uploaded.push(path);
            payload[f.name] = path;
            if (f.nameCol) payload[f.nameCol] = newFile.name;
            if (f.sizeCol) payload[f.sizeCol] = newFile.size;
            if (existing && existing[f.name]) old.push(existing[f.name]);
          } else if (val) {
            payload[f.name] = val;
          } else {
            payload[f.name] = null;
            if (f.nameCol) payload[f.nameCol] = null;
            if (f.sizeCol) payload[f.sizeCol] = null;
            if (existing && existing[f.name]) old.push(existing[f.name]);
          }
        } else if (f.type === 'files') {
          const list: string[] = [...((val as string[]) || [])];
          const newFiles = pending[f.name] ?? [];
          for (const file of newFiles) {
            setProgress(0);
            const path = await uploadFile(file, config.folder || config.table, setProgress);
            uploaded.push(path);
            list.push(path);
          }
          payload[f.name] = list;
          if (existing) ((existing[f.name] as string[]) || []).filter((p) => !list.includes(p)).forEach((p) => old.push(p));
        } else if (f.type === 'multiref' || f.type === 'custom') {
          payload[f.name] = val || [];
        } else {
          const text = String(val ?? '').trim();
          payload[f.name] = text === '' ? null : text;
        }
      }

      if (config.slugFrom && !existing) {
        payload.slug = `${slugify(String(payload[config.slugFrom] || ''))}-${randomId().slice(0, 4)}`;
      }

      const result = editing.id
        ? await supabase.from(config.table).update(payload).eq('id', editing.id)
        : await supabase.from(config.table).insert(payload);
      if (result.error) throw new Error(result.error.message);

      await removeFiles(old);
      toast('Saved.', 'good');
      closeForm();
      await load();
    } catch (e: any) {
      await removeFiles(uploaded);
      toast(e?.message ? `Could not save: ${e.message}` : 'Could not save. Try again.', 'bad');
    } finally {
      setSaving(false);
      setProgress(null);
    }
  }

  async function togglePublish(row: Row) {
    const { error } = await supabase
      .from(config.table)
      .update({ [config.publishField]: !row[config.publishField] })
      .eq('id', row.id);
    if (error) {
      toast(`Could not update: ${error.message}`, 'bad');
      return;
    }
    toast(row[config.publishField] ? 'Moved back to draft.' : 'Published.', 'good');
    load();
  }

  async function removeRow(row: Row) {
    const { error } = await supabase.from(config.table).delete().eq('id', row.id);
    if (error) {
      toast(`Could not delete: ${error.message}`, 'bad');
      return;
    }
    const paths: string[] = [];
    config.fields.forEach((f) => {
      if (f.type === 'file' && row[f.name]) paths.push(row[f.name]);
      if (f.type === 'files') paths.push(...((row[f.name] as string[]) || []));
    });
    await removeFiles(paths);
    setConfirmRow(null);
    toast('Deleted.', 'good');
    load();
  }

  const filterOptions = useMemo(() => {
    const out: Record<string, string[]> = {};
    (config.filters ?? []).forEach((f) => {
      const all = rows.flatMap((r) => (f.getAll ? f.getAll(r) : [f.get ? f.get(r) : '']));
      out[f.label] = Array.from(new Set(all.filter(Boolean))).sort();
    });
    return out;
  }, [rows, config.filters]);

  const visible = useMemo(() => {
    const s = query.trim().toLowerCase();
    let list = rows.filter((r) => {
      const hay = `${r[config.titleField] ?? ''} ${config.searchText ? config.searchText(r) : ''}`.toLowerCase();
      if (s && !hay.includes(s)) return false;
      for (const f of config.filters ?? []) {
        const sel = filterVals[f.label];
        if (sel) {
          const have = f.getAll ? f.getAll(r) : [f.get ? f.get(r) : ''];
          if (!have.includes(sel)) return false;
        }
      }
      return true;
    });
    list = [...list];
    if (sort === 'old') list.reverse();
    if (sort === 'az') list.sort((a, b) => String(a[config.titleField] ?? '').localeCompare(String(b[config.titleField] ?? '')));
    return list;
  }, [rows, query, filterVals, sort, config]);

  const [onLabel, offLabel] = config.publishLabels ?? ['Published', 'Draft'];

  /* ---------------- form view ---------------- */
  if (editing) {
    const v = editing.values;
    return (
      <>
        <div className="ahead">
          <h2>{editing.id ? `Edit ${config.singular}` : `Add ${config.singular}`}</h2>
          <button className="btn ghost" type="button" onClick={closeForm} disabled={saving}>
            Cancel
          </button>
        </div>
        <form
          className="f"
          noValidate
          onSubmit={(e) => {
            e.preventDefault();
            save();
          }}
        >
          {config.fields
            .filter((f) => !f.hidden && f.type !== 'custom')
            .map((f) => {
              const id = `f_${f.name}`;
              const err = fieldErr[f.name];
              const cls = f.full || f.type === 'textarea' || f.type === 'files' || f.type === 'multiref' ? 'full' : '';
              if (f.type === 'checkbox') {
                return (
                  <label key={f.name} className={`chk ${cls || 'full'}`} htmlFor={id}>
                    <input id={id} type="checkbox" checked={Boolean(v[f.name])} onChange={(e) => setValue(f.name, e.target.checked)} />
                    {f.label}
                  </label>
                );
              }
              if (f.type === 'multiref') {
                const opts = refs[f.name] ?? [];
                const sel: string[] = v[f.name] || [];
                return (
                  <fieldset key={f.name} className="full" style={{ border: '1px solid var(--line)', borderRadius: 12, padding: '12px 14px' }}>
                    <legend style={{ color: 'var(--fg2)', fontSize: 13.5, padding: '0 6px' }}>{f.label}</legend>
                    {opts.length ? (
                      opts.map((o) => (
                        <label key={o.id} className="chk" style={{ padding: '4px 0' }}>
                          <input
                            type="checkbox"
                            checked={sel.includes(o.id)}
                            onChange={(e) =>
                              setValue(f.name, e.target.checked ? [...sel, o.id] : sel.filter((x) => x !== o.id))
                            }
                          />
                          {o.label}
                        </label>
                      ))
                    ) : (
                      <span style={{ color: 'var(--fg2)', fontSize: 14 }}>Nothing to connect yet.</span>
                    )}
                  </fieldset>
                );
              }
              if (f.type === 'file') {
                const newFile = pending[f.name]?.[0];
                return (
                  <div key={f.name} className="full">
                    <label className="l" htmlFor={id}>
                      {f.label}
                      <input
                        id={id}
                        type="file"
                        accept={(f.mimes ?? []).join(',')}
                        onChange={(e) => {
                          onFiles(f, e.target.files);
                          e.target.value = '';
                        }}
                      />
                      <small>
                        {f.hint ?? `Up to ${f.maxMB ?? 10} MB.`}
                        {newFile ? ` Selected: ${newFile.name} (${fmtSize(newFile.size)}). It uploads when you save.` : ''}
                      </small>
                    </label>
                    {!newFile && v[f.name] ? (
                      <div className="fact" style={{ justifyContent: 'flex-start', marginTop: 8 }}>
                        <FileLink path={v[f.name]}>Open current file</FileLink>
                        <button className="btn sm danger" type="button" onClick={() => setValue(f.name, '')}>
                          <Icon name="trash" />
                          Remove file
                        </button>
                      </div>
                    ) : null}
                    {err ? (
                      <p className="err" role="alert">
                        {err}
                      </p>
                    ) : null}
                  </div>
                );
              }
              if (f.type === 'files') {
                const paths: string[] = v[f.name] || [];
                const newOnes = pending[f.name] ?? [];
                return (
                  <div key={f.name} className="full">
                    <label className="l" htmlFor={id}>
                      {f.label}
                      <input
                        id={id}
                        type="file"
                        multiple
                        accept={(f.mimes ?? []).join(',')}
                        onChange={(e) => {
                          onFiles(f, e.target.files);
                          e.target.value = '';
                        }}
                      />
                      <small>
                        {f.hint ?? `Up to ${f.maxMB ?? 10} MB each.`}
                        {newOnes.length ? ` ${newOnes.length} new file${newOnes.length === 1 ? '' : 's'} will upload when you save.` : ''}
                      </small>
                    </label>
                    {err ? (
                      <p className="err" role="alert">
                        {err}
                      </p>
                    ) : null}
                    {paths.length || newOnes.length ? (
                      <div className="shots" style={{ marginTop: 12 }}>
                        {paths.map((p) => (
                          <figure key={p}>
                            <SignedImage className="thumb" path={p} alt="Uploaded image" />
                            <button type="button" aria-label="Remove image" onClick={() => setValue(f.name, paths.filter((x) => x !== p))}>
                              <Icon name="x" />
                            </button>
                          </figure>
                        ))}
                        {newOnes.map((file, i) => (
                          <figure key={`${file.name}-${i}`}>
                            <span className="pill pur" style={{ height: 60 }}>
                              {file.name.slice(0, 18)}
                            </span>
                            <button
                              type="button"
                              aria-label={`Remove ${file.name}`}
                              onClick={() => setPending((prev) => ({ ...prev, [f.name]: (prev[f.name] ?? []).filter((_, j) => j !== i) }))}
                            >
                              <Icon name="x" />
                            </button>
                          </figure>
                        ))}
                      </div>
                    ) : null}
                  </div>
                );
              }
              if (f.type === 'textarea') {
                return (
                  <label key={f.name} className={`l ${cls}`} htmlFor={id}>
                    {f.label}
                    <textarea id={id} value={v[f.name] ?? ''} placeholder={f.placeholder} onChange={(e) => setValue(f.name, e.target.value)} />
                    {f.hint ? <small>{f.hint}</small> : null}
                    {err ? <span className="err">{err}</span> : null}
                  </label>
                );
              }
              if (f.type === 'select') {
                return (
                  <label key={f.name} className={`l ${cls}`} htmlFor={id}>
                    {f.label}
                    <select id={id} value={v[f.name] ?? ''} onChange={(e) => setValue(f.name, e.target.value)}>
                      {!f.required ? <option value="">Not set</option> : null}
                      {(f.options ?? []).map((o) => (
                        <option key={optValue(o)} value={optValue(o)}>
                          {optLabel(o)}
                        </option>
                      ))}
                    </select>
                    {f.hint ? <small>{f.hint}</small> : null}
                    {err ? <span className="err">{err}</span> : null}
                  </label>
                );
              }
              const inputType = f.type === 'tags' ? 'text' : f.type;
              return (
                <label key={f.name} className={`l ${cls}`} htmlFor={id}>
                  {f.label}
                  <input
                    id={id}
                    type={inputType}
                    value={v[f.name] ?? ''}
                    placeholder={f.placeholder}
                    onChange={(e) => setValue(f.name, e.target.value)}
                  />
                  {f.type === 'tags' ? <small>{f.hint ?? 'Separate with commas'}</small> : f.hint ? <small>{f.hint}</small> : null}
                  {err ? <span className="err">{err}</span> : null}
                </label>
              );
            })}

          {config.renderExtra ? <div className="full">{config.renderExtra({ values: v, set: patchValues, rows })}</div> : null}

          {dupMsg ? (
            <div className="alert full" role="alert">
              {dupMsg}{' '}
              <button className="btn sm" type="button" onClick={() => save(true)}>
                Save anyway
              </button>
            </div>
          ) : null}

          {progress !== null ? (
            <div className="full" role="status" aria-live="polite">
              <div className="meter">
                <i style={{ width: `${progress}%` }} />
              </div>
              <small style={{ color: 'var(--fg2)' }}>Uploading {progress}%</small>
            </div>
          ) : null}

          <div className="fact full">
            <button className="btn primary" type="submit" disabled={saving}>
              {saving ? 'Saving...' : `Save ${config.singular}`}
            </button>
          </div>
        </form>
      </>
    );
  }

  /* ---------------- list view ---------------- */
  return (
    <>
      <div className="ahead">
        <h2>{config.title}</h2>
        <button className="btn primary" type="button" onClick={openNew}>
          <Icon name="plus" />
          Add {config.singular}
        </button>
      </div>
      {config.intro ? <p style={{ color: 'var(--fg2)', marginBottom: 16 }}>{config.intro}</p> : null}

      <div className="tools">
        <label className="sr" htmlFor="q">
          Search
        </label>
        <input id="q" style={{ maxWidth: 260 }} placeholder="Search" value={query} onChange={(e) => setQuery(e.target.value)} />
        {(config.filters ?? []).map((f) => (
          <span key={f.label} style={{ display: 'contents' }}>
            <label className="sr" htmlFor={`flt_${f.label}`}>
              {f.label}
            </label>
            <select
              id={`flt_${f.label}`}
              style={{ maxWidth: 190 }}
              value={filterVals[f.label] ?? ''}
              onChange={(e) => setFilterVals((prev) => ({ ...prev, [f.label]: e.target.value }))}
            >
              <option value="">All {f.label.toLowerCase()}</option>
              {(filterOptions[f.label] ?? []).map((o) => (
                <option key={o} value={o}>
                  {o}
                </option>
              ))}
            </select>
          </span>
        ))}
        <label className="sr" htmlFor="sortby">
          Sort
        </label>
        <select id="sortby" style={{ maxWidth: 160 }} value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="new">Newest first</option>
          <option value="old">Oldest first</option>
          <option value="az">A to Z</option>
        </select>
      </div>

      {loading ? (
        <p style={{ color: 'var(--fg2)' }} role="status">
          Loading...
        </p>
      ) : loadError ? (
        <div className="alert" role="alert">
          Could not load {config.title.toLowerCase()}: {loadError}{' '}
          <button className="btn sm" type="button" onClick={load}>
            Try again
          </button>
        </div>
      ) : !rows.length ? (
        <div className="empty">
          <b>Nothing here yet</b>
          <span>{config.emptyHint}</span>
        </div>
      ) : !visible.length ? (
        <div className="empty">
          <b>No matches</b>
          <span>Change the search or filters.</span>
        </div>
      ) : (
        <div className="rows">
          {visible.map((row) => {
            const on = Boolean(row[config.publishField]);
            const filePath = config.fields.find((f) => f.type === 'file')?.name;
            const preview = config.previewHref ? config.previewHref(row) : null;
            return (
              <div className="rowi" key={row.id}>
                <div className="t">
                  <b>{row[config.titleField]}</b>
                  <span>{config.subtitle ? config.subtitle(row) : ''}</span>
                </div>
                <span className={`pill ${on ? 'ok' : 'mute'}`}>{on ? onLabel : offLabel}</span>
                <div className="ac">
                  {filePath && row[filePath] ? <FileLink path={row[filePath]}>Open file</FileLink> : null}
                  {preview && on ? (
                    <a className="btn sm" href={preview} target="_blank" rel="noopener noreferrer">
                      <Icon name="eye" />
                      View
                    </a>
                  ) : null}
                  <button className="btn sm" type="button" onClick={() => togglePublish(row)}>
                    {on ? 'Unpublish' : 'Publish'}
                  </button>
                  <button className="btn sm" type="button" onClick={() => openEdit(row)}>
                    <Icon name="edit" />
                    Edit
                  </button>
                  <button
                    className="btn sm danger"
                    type="button"
                    aria-label={`Delete ${row[config.titleField]}`}
                    onClick={() => setConfirmRow(row)}
                  >
                    <Icon name="trash" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {confirmRow ? (
        <div className="scrim" role="presentation" onClick={() => setConfirmRow(null)}>
          <div className="dlg" role="dialog" aria-modal="true" aria-labelledby="deltitle" onClick={(e) => e.stopPropagation()}>
            <h2 id="deltitle">Delete this {config.singular}?</h2>
            <p style={{ color: 'var(--fg2)' }}>
              &ldquo;{confirmRow[config.titleField]}&rdquo; and its uploaded files will be removed. This cannot be undone.
            </p>
            <div className="fact">
              <button className="btn" type="button" onClick={() => setConfirmRow(null)} autoFocus>
                Cancel
              </button>
              <button className="btn danger" type="button" onClick={() => removeRow(confirmRow)}>
                Delete
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
