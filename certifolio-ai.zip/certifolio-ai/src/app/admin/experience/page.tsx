'use client';

import ResourceManager from '@/components/admin/ResourceManager';
import type { ResourceConfig } from '@/lib/admin-types';
import { fmtDate } from '@/lib/utils';

const TYPES = [
  { value: 'applied', label: 'Application submitted' },
  { value: 'shortlisted', label: 'Shortlisted' },
  { value: 'selected', label: 'Selected (confirmed)' },
  { value: 'ongoing', label: 'Ongoing' },
  { value: 'completed', label: 'Completed' },
];

const config: ResourceConfig = {
  table: 'experiences',
  title: 'Experience and internships',
  singular: 'entry',
  titleField: 'role',
  publishField: 'published',
  emptyHint: 'Add an entry. Each one carries a status, so an application is never shown as a completed internship.',
  fields: [
    { name: 'organization', label: 'Organization', type: 'text', required: true },
    { name: 'role', label: 'Role or internship title', type: 'text', required: true },
    {
      name: 'entry_type',
      label: 'Status',
      type: 'select',
      required: true,
      options: TYPES,
      hint: 'Pick what is actually true today.',
    },
    { name: 'start_date', label: 'Start date', type: 'date' },
    { name: 'end_date', label: 'End date', type: 'date' },
    { name: 'description', label: 'Description', type: 'textarea' },
    { name: 'skills', label: 'Skills learned', type: 'tags', full: true },
    { name: 'proof_url', label: 'Proof link', type: 'url', full: true },
    { name: 'published', label: 'Show on public site', type: 'checkbox' },
  ],
  subtitle: (r) =>
    [r.organization, TYPES.find((t) => t.value === r.entry_type)?.label, r.start_date ? fmtDate(r.start_date) : '']
      .filter(Boolean)
      .join(' · '),
  searchText: (r) => `${r.organization ?? ''} ${(r.skills || []).join(' ')}`,
  filters: [{ label: 'Status', get: (r) => TYPES.find((t) => t.value === r.entry_type)?.label ?? '' }],
};

export default function ExperiencePage() {
  return <ResourceManager config={config} />;
}
