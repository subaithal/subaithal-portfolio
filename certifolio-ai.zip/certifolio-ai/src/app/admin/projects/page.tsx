'use client';

import CaptionTools from '@/components/admin/CaptionTools';
import ResourceManager from '@/components/admin/ResourceManager';
import type { ResourceConfig } from '@/lib/admin-types';

const config: ResourceConfig = {
  table: 'projects',
  title: 'Projects',
  singular: 'project',
  folder: 'projects',
  titleField: 'title',
  publishField: 'published',
  slugFrom: 'title',
  emptyHint: 'Run supabase/schema.sql to add the four starter projects, or add one here.',
  intro:
    'The starter projects hold only the links you gave. Add summaries, technologies and real screenshots, then publish each one.',
  fields: [
    { name: 'title', label: 'Project title', type: 'text', required: true, full: true },
    { name: 'summary', label: 'Short summary', type: 'textarea' },
    { name: 'problem', label: 'Problem statement', type: 'textarea' },
    { name: 'solution', label: 'Solution and features', type: 'textarea' },
    { name: 'tech', label: 'Technologies actually used', type: 'tags', full: true },
    { name: 'live_url', label: 'Live demo URL', type: 'url' },
    { name: 'repo_url', label: 'GitHub repository URL', type: 'url' },
    {
      name: 'project_status',
      label: 'Project status',
      type: 'select',
      options: ['In progress', 'Completed', 'Live', 'On hold'],
    },
    { name: 'category', label: 'Category', type: 'text' },
    { name: 'tags', label: 'Tags', type: 'tags' },
    {
      name: 'video_url',
      label: 'Video URL',
      type: 'url',
      hint: 'A link to a hosted video. Uploading large video files is not supported on the free plan.',
    },
    { name: 'dev_details', label: 'Development details', type: 'textarea' },
    {
      name: 'images',
      label: 'Screenshots and images',
      type: 'files',
      mimes: ['image/png', 'image/jpeg', 'image/webp'],
      maxMB: 10,
      hint: 'PNG, JPG or WebP, up to 10 MB each.',
    },
    { name: 'linkedin_caption', label: 'LinkedIn caption', type: 'text', hidden: true },
    { name: 'linkedin_post_url', label: 'LinkedIn post URL', type: 'url', hidden: true },
    { name: 'published', label: 'Show on public site', type: 'checkbox' },
  ],
  subtitle: (r) =>
    `${r.summary ? 'Summary added' : 'Summary needed'} · ${(r.tech || []).length} technologies · ${(r.images || []).length} screenshots`,
  searchText: (r) => `${r.summary ?? ''} ${(r.tags || []).join(' ')} ${(r.tech || []).join(' ')}`,
  filters: [{ label: 'Status', get: (r) => r.project_status ?? '' }],
  previewHref: (r) => `/projects/${r.slug}`,
  renderExtra: ({ values, set }) => <CaptionTools values={values} set={set} />,
};

export default function ProjectsPage() {
  return <ResourceManager config={config} />;
}
