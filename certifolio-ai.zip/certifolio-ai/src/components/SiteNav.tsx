'use client';

import { useState } from 'react';
import Icon from './Icon';

const LINKS: [string, string][] = [
  ['about', 'About'],
  ['skills', 'Skills'],
  ['certificates', 'Certificates'],
  ['projects', 'Projects'],
  ['experience', 'Experience'],
  ['achievements', 'Achievements'],
  ['education', 'Education'],
  ['resume', 'Resume'],
  ['contact', 'Contact'],
];

export default function SiteNav() {
  const [open, setOpen] = useState(false);
  return (
    <header className="topbar">
      <div className="wrap">
        <a className="brand" href="/">
          <i />
          CertiFolio <span>AI</span>
        </a>
        <nav className="nav" aria-label="Sections">
          {LINKS.map(([id, label]) => (
            <a key={id} href={`/#${id}`}>
              {label}
            </a>
          ))}
        </nav>
        <button
          className="burger"
          type="button"
          aria-label="Menu"
          aria-expanded={open}
          onClick={() => setOpen((o) => !o)}
        >
          <Icon name="menu" />
        </button>
      </div>
      <nav className={`mnav ${open ? 'open' : ''}`} aria-label="Sections">
        {LINKS.map(([id, label]) => (
          <a key={id} href={`/#${id}`} onClick={() => setOpen(false)}>
            {label}
          </a>
        ))}
      </nav>
    </header>
  );
}
