'use client';

import { useCallback, useEffect, useState, type FormEvent } from 'react';
import Icon from '@/components/Icon';
import { SignedImage } from '@/components/admin/Signed';
import { useToast } from '@/components/admin/Toast';
import { getBrowserClient } from '@/lib/supabase/client';
import { removeFiles, uploadFile } from '@/lib/upload';
import { checkFile } from '@/lib/utils';

export default function ProfilePage() {
  const supabase = getBrowserClient();
  const toast = useToast();
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [bio, setBio] = useState('');
  const [email, setEmail] = useState('');
  const [linkedin, setLinkedin] = useState('');
  const [github, setGithub] = useState('');
  const [photo, setPhoto] = useState<string | null>(null);
  const [progress, setProgress] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('site_profile').select('*').eq('id', 1).maybeSingle();
    if (error) {
      setLoadError(error.message);
    } else {
      setLoadError('');
      setBio(data?.bio ?? '');
      setEmail(data?.email ?? '');
      setLinkedin(data?.linkedin ?? '');
      setGithub(data?.github ?? '');
      setPhoto(data?.photo_path ?? null);
    }
    setLoading(false);
  }, [supabase]);

  useEffect(() => {
    load();
  }, [load]);

  async function saveDetails(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.from('site_profile').upsert({
      id: 1,
      bio: bio.trim() || null,
      email: email.trim() || null,
      linkedin: linkedin.trim() || null,
      github: github.trim() || null,
      photo_path: photo,
      updated_at: new Date().toISOString(),
    });
    setBusy(false);
    if (error) toast(`Could not save: ${error.message}`, 'bad');
    else toast('Profile saved.', 'good');
  }

  async function onPhoto(files: FileList | null) {
    const file = files?.[0];
    if (!file) return;
    const problem = checkFile(file, ['image/png', 'image/jpeg', 'image/webp'], 5);
    if (problem) {
      toast(problem, 'bad');
      return;
    }
    setBusy(true);
    let path = '';
    try {
      setProgress(0);
      path = await uploadFile(file, 'profile', setProgress);
      const { error } = await supabase.from('site_profile').upsert({ id: 1, photo_path: path, updated_at: new Date().toISOString() });
      if (error) throw new Error(error.message);
      if (photo) await removeFiles([photo]);
      setPhoto(path);
      toast('Photo updated.', 'good');
    } catch (e: any) {
      if (path) await removeFiles([path]);
      toast(e?.message ? `Could not upload: ${e.message}` : 'Could not upload. Try again.', 'bad');
    } finally {
      setBusy(false);
      setProgress(null);
    }
  }

  async function removePhoto() {
    if (!photo) return;
    setBusy(true);
    const { error } = await supabase.from('site_profile').upsert({ id: 1, photo_path: null, updated_at: new Date().toISOString() });
    if (error) {
      toast(`Could not remove: ${error.message}`, 'bad');
    } else {
      await removeFiles([photo]);
      setPhoto(null);
      toast('Photo removed.', 'good');
    }
    setBusy(false);
  }

  if (loading)
    return (
      <p style={{ color: 'var(--fg2)' }} role="status">
        Loading...
      </p>
    );
  if (loadError)
    return (
      <div className="alert" role="alert">
        Could not load the profile: {loadError}{' '}
        <button className="btn sm" type="button" onClick={load}>
          Try again
        </button>
      </div>
    );

  return (
    <>
      <div className="ahead">
        <h2>Profile and links</h2>
      </div>
      <div className="panel">
        <h3>Professional photo</h3>
        <div style={{ display: 'flex', gap: 16, alignItems: 'center', flexWrap: 'wrap' }}>
          {photo ? (
            <SignedImage className="thumb" path={photo} alt="Current portrait" />
          ) : (
            <div className="shot-empty" style={{ width: 90, height: 112, aspectRatio: 'auto' }}>
              No photo
            </div>
          )}
          <div style={{ flex: '1 1 240px' }}>
            <label className="l" htmlFor="photo_file">
              Upload your own photo
              <input id="photo_file" type="file" accept="image/png,image/jpeg,image/webp" disabled={busy} onChange={(e) => { onPhoto(e.target.files); e.target.value = ''; }} />
              <small>PNG, JPG or WebP, up to 5 MB. Portrait orientation works best.</small>
            </label>
            {photo ? (
              <button className="btn sm danger" type="button" style={{ marginTop: 10 }} onClick={removePhoto} disabled={busy}>
                <Icon name="trash" />
                Remove photo
              </button>
            ) : null}
            {progress !== null ? (
              <div role="status" aria-live="polite">
                <div className="meter">
                  <i style={{ width: `${progress}%` }} />
                </div>
              </div>
            ) : null}
          </div>
        </div>
      </div>

      <form className="f panel" onSubmit={saveDetails} noValidate>
        <h3 className="full">Details</h3>
        <label className="l full" htmlFor="bio">
          About me
          <textarea id="bio" value={bio} onChange={(e) => setBio(e.target.value)} />
          <small>Written by you. Nothing is generated.</small>
        </label>
        <label className="l" htmlFor="email">
          Public email (optional)
          <input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </label>
        <span />
        <label className="l" htmlFor="linkedin">
          LinkedIn URL
          <input id="linkedin" type="url" value={linkedin} onChange={(e) => setLinkedin(e.target.value)} />
        </label>
        <label className="l" htmlFor="github">
          GitHub URL
          <input id="github" type="url" value={github} onChange={(e) => setGithub(e.target.value)} />
        </label>
        <div className="fact full">
          <button className="btn primary" type="submit" disabled={busy}>
            Save profile
          </button>
        </div>
      </form>
    </>
  );
}
