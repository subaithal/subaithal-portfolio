'use client';

import { createContext, useCallback, useContext, useRef, useState, type ReactNode } from 'react';

type Kind = 'good' | 'bad' | '';
type Push = (message: string, kind?: Kind) => void;

const ToastContext = createContext<Push>(() => {});

export function useToast(): Push {
  return useContext(ToastContext);
}

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toast, setToast] = useState<{ message: string; kind: Kind } | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const push = useCallback<Push>((message, kind = '') => {
    setToast({ message, kind });
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setToast(null), 4200);
  }, []);

  return (
    <ToastContext.Provider value={push}>
      {children}
      <div aria-live="polite">
        {toast ? (
          <div className={`toast ${toast.kind}`} role="status">
            {toast.message}
          </div>
        ) : null}
      </div>
    </ToastContext.Provider>
  );
}
