'use client';

import ResourceManager from '@/components/admin/ResourceManager';
import type { ResourceConfig } from '@/lib/admin-types';
import { fmtDate } from '@/lib/utils';

const config: ResourceConfig = {
  table: 'achievements',
  title: 'Achievements and events',
  singular: 'achievement',
  folder: 'achievements',
  titleField: 'title',
  publishField: 'published',
  emptyHint: 'Add awards, events or recognitions, with optional proof.',
  fields: [
    { name: 'title', label: 'Achievement title', type: 'text', required: true, full: true },
    { name: 'event', label: 'Event or organization', type: 'text' },
    { name: 'achieved_on', label: 'Date', type: 'date' },
    { name: 'description', label: 'Description', type: 'textarea' },
    { name: 'link_url', label: 'Relevant link', type: 'url', full: true },
    {
      name: 'file_path',
      label: 'Certificate or proof file',
      type: 'file',
      mimes: ['application/pdf', 'image/png', 'image/jpeg'],
      maxMB: 10,
      nameCol: 'file_name',
      sizeCol: 'file_size',
      hint: 'PDF, PNG or JPG, up to 10 MB.',
    },
    { name: 'published', label: 'Show on public site', type: 'checkbox' },
  ],
  subtitle: (r) => [r.event, r.achieved_on ? fmtDate(r.achieved_on) : ''].filter(Boolean).join(' · '),
  searchText: (r) => `${r.event ?? ''} ${r.description ?? ''}`,
  filters: [{ label: 'Years', get: (r) => (r.achieved_on ? String(r.achieved_on).slice(0, 4) : '') }],
};

export default function AchievementsPage() {
  return <ResourceManager config={config} />;
}
