'use client';

import { useEffect, useState, type FormEvent } from 'react';
import { getBrowserClient, hasSupabaseEnv } from '@/lib/supabase/client';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [notAdmin, setNotAdmin] = useState(false);
  const configured = hasSupabaseEnv();

  useEffect(() => {
    setNotAdmin(new URLSearchParams(window.location.search).get('error') === 'notadmin');
  }, []);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError('');
    if (!email.trim() || !password) {
      setError('Enter your email and password.');
      return;
    }
    setBusy(true);
    try {
      const supabase = getBrowserClient();
      const { data, error: authError } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
      if (authError || !data.user) {
        setError('Sign in failed. Check your email and password.');
        return;
      }
      const { data: adminRow } = await supabase.from('admins').select('user_id').eq('user_id', data.user.id).maybeSingle();
      if (!adminRow) {
        await supabase.auth.signOut();
        setError('This account is not an administrator of the portfolio.');
        return;
      }
      window.location.assign('/admin');
    } catch {
      setError('Could not reach the server. Check your connection and try again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <main id="main" className="login">
      <a className="back" href="/">
        Back to portfolio
      </a>
      <h1>Admin sign in</h1>
      {!configured ? (
        <div className="alert" role="alert">
          Supabase is not connected yet. Add the two environment variables from .env.example, then redeploy.
        </div>
      ) : null}
      {notAdmin ? (
        <div className="alert" role="alert">
          That account is signed in but is not listed as an administrator.
        </div>
      ) : null}
      <form className="f" style={{ gridTemplateColumns: '1fr' }} onSubmit={submit} noValidate>
        <label className="l" htmlFor="email">
          Email
          <input id="email" type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} />
        </label>
        <label className="l" htmlFor="password">
          Password
          <input
            id="password"
            type="password"
            autoComplete="current-password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </label>
        {error ? (
          <p className="err" role="alert">
            {error}
          </p>
        ) : null}
        <button className="btn primary" type="submit" disabled={busy || !configured}>
          {busy ? 'Signing in...' : 'Sign in'}
        </button>
      </form>
    </main>
  );
}
