export const SKILL_CATEGORIES = ['Programming', 'Data analytics', 'AI learning', 'Tools and technologies'];
export const SKILL_STAGES = ['Learning', 'Practising', 'Used in a project'];

const VOCAB = [
  'Python', 'SQL', 'Machine Learning', 'Deep Learning', 'Data Analysis', 'Data Visualization',
  'Generative AI', 'Prompt Engineering', 'Natural Language Processing', 'Computer Vision', 'Statistics',
  'Power BI', 'Tableau', 'Excel', 'Pandas', 'NumPy', 'TensorFlow', 'PyTorch', 'Git', 'JavaScript',
  'TypeScript', 'React', 'HTML', 'CSS', 'Cloud Computing', 'Large Language Models', 'Neural Networks',
  'Data Science', 'Artificial Intelligence', 'UI/UX Design', 'Figma', 'Java', 'C++', 'Scikit-learn',
];

const SYNONYMS: Record<string, string> = {
  llm: 'Large Language Models',
  llms: 'Large Language Models',
  nlp: 'Natural Language Processing',
  genai: 'Generative AI',
  ml: 'Machine Learning',
  ai: 'Artificial Intelligence',
};

/** Simple keyword matching against a fixed list. This is a suggestion aid, not proof of skill. */
export function suggestSkills(text: string): string[] {
  const t = ' ' + text.toLowerCase().replace(/[^a-z0-9+#./ ]/g, ' ') + ' ';
  const found = new Set<string>();
  VOCAB.forEach((v) => {
    if (t.includes(' ' + v.toLowerCase() + ' ') || t.includes(v.toLowerCase())) found.add(v);
  });
  Object.keys(SYNONYMS).forEach((k) => {
    if (t.includes(' ' + k + ' ')) found.add(SYNONYMS[k]);
  });
  return Array.from(found);
}
