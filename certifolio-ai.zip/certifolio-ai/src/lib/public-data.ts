import { publicClient } from './supabase/public';
import { BUCKET } from './utils';

export type Row = Record<string, any>;

export interface SiteData {
  profile: Row;
  skills: Row[];
  certs: Row[];
  projects: Row[];
  exps: Row[];
  achs: Row[];
  resume: Row | null;
  urls: Record<string, string>;
}

async function rows(query: any): Promise<Row[]> {
  try {
    const { data, error } = await query;
    if (error) {
      console.error('[public-data]', error.message);
      return [];
    }
    return (data as Row[]) ?? [];
  } catch (e) {
    console.error('[public-data]', e);
    return [];
  }
}

async function signedUrls(paths: string[]): Promise<Record<string, string>> {
  const sb = publicClient();
  const out: Record<string, string> = {};
  const unique = Array.from(new Set(paths.filter(Boolean)));
  if (!sb || !unique.length) return out;
  try {
    const { data, error } = await sb.storage.from(BUCKET).createSignedUrls(unique, 3600);
    if (error || !data) return out;
    data.forEach((d: any) => {
      if (d && d.path && d.signedUrl) out[d.path] = d.signedUrl;
    });
  } catch (e) {
    console.error('[public-data] signing failed', e);
  }
  return out;
}

/** Returns null when Supabase is not configured yet. */
export async function getSiteData(): Promise<SiteData | null> {
  const sb = publicClient();
  if (!sb) return null;

  const [profileRows, skills, certs, projects, exps, achs, resumes] = await Promise.all([
    rows(sb.from('site_profile').select('bio,email,linkedin,github,photo_path').eq('id', 1)),
    rows(sb.from('skills').select('id,name,category,stage,description').eq('is_public', true).order('name')),
    rows(
      sb
        .from('certificates')
        .select('id,title,issuer,issue_date,verify_url,description,tags,skills,file_path')
        .eq('published', true)
        .order('issue_date', { ascending: false, nullsFirst: false }),
    ),
    rows(
      sb
        .from('projects')
        .select('id,slug,title,summary,tech,images,live_url,repo_url,project_status')
        .eq('published', true)
        .order('created_at', { ascending: true }),
    ),
    rows(
      sb
        .from('experiences')
        .select('id,organization,role,entry_type,start_date,end_date,description,skills,proof_url')
        .eq('published', true)
        .order('start_date', { ascending: false, nullsFirst: false }),
    ),
    rows(
      sb
        .from('achievements')
        .select('id,title,event,achieved_on,description,link_url,file_path')
        .eq('published', true)
        .order('achieved_on', { ascending: false, nullsFirst: false }),
    ),
    rows(sb.from('resumes').select('file_path,file_name,file_size').eq('is_published', true).limit(1)),
  ]);

  const profile = profileRows[0] ?? {};
  const resume = resumes[0] ?? null;

  const paths: string[] = [];
  if (profile.photo_path) paths.push(profile.photo_path);
  certs.forEach((c) => c.file_path && paths.push(c.file_path));
  achs.forEach((a) => a.file_path && paths.push(a.file_path));
  if (resume?.file_path) paths.push(resume.file_path);

  const urls = await signedUrls(paths);
  return { profile, skills, certs, projects, exps, achs, resume, urls };
}

export async function getProject(slug: string): Promise<{ project: Row; urls: Record<string, string> } | null> {
  const sb = publicClient();
  if (!sb) return null;
  const list = await rows(
    sb
      .from('projects')
      .select(
        'id,slug,title,summary,problem,solution,tech,images,video_url,live_url,repo_url,project_status,category,tags,dev_details,linkedin_post_url',
      )
      .eq('slug', slug)
      .eq('published', true)
      .limit(1),
  );
  const project = list[0];
  if (!project) return null;
  const urls = await signedUrls(project.images ?? []);
  return { project, urls };
}
