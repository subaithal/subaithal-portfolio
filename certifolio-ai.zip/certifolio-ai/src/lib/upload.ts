import { getBrowserClient } from './supabase/client';
import { BUCKET, randomId, safeName } from './utils';

/**
 * Uploads one file to the private bucket with real progress reporting.
 * Runs in the browser with the signed-in admin's session, so storage policies decide access.
 */
export async function uploadFile(
  file: File,
  folder: string,
  onProgress: (percent: number) => void,
): Promise<string> {
  const supabase = getBrowserClient();
  const { data } = await supabase.auth.getSession();
  const session = data.session;
  if (!session) throw new Error('Your session expired. Sign in again, then retry.');

  const path = `${folder}/${randomId()}-${safeName(file.name)}`;
  const url = `${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/${BUCKET}/${path}`;

  await new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', url);
    xhr.setRequestHeader('Authorization', `Bearer ${session.access_token}`);
    xhr.setRequestHeader('apikey', process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY as string);
    xhr.setRequestHeader('x-upsert', 'false');
    xhr.setRequestHeader('Content-Type', file.type);
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100));
    };
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        resolve();
        return;
      }
      let message = `Upload failed (code ${xhr.status}).`;
      try {
        const body = JSON.parse(xhr.responseText);
        if (body && body.message) message = String(body.message);
      } catch {
        /* keep default message */
      }
      reject(new Error(message));
    };
    xhr.onerror = () => reject(new Error('Network error during upload. Check your connection and try again.'));
    xhr.send(file);
  });

  return path;
}

export async function removeFiles(paths: string[]): Promise<void> {
  const list = paths.filter(Boolean);
  if (!list.length) return;
  await getBrowserClient().storage.from(BUCKET).remove(list);
}
