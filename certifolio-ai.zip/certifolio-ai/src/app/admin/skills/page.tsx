'use client';

import ResourceManager from '@/components/admin/ResourceManager';
import type { ResourceConfig } from '@/lib/admin-types';
import { SKILL_CATEGORIES, SKILL_STAGES } from '@/lib/skills';

const config: ResourceConfig = {
  table: 'skills',
  title: 'Skills',
  singular: 'skill',
  titleField: 'name',
  publishField: 'is_public',
  publishLabels: ['Public', 'Hidden'],
  emptyHint: 'Add skills yourself. Label each one with your real learning stage. There are no proficiency scores.',
  intro: 'Choose which skills are public and label each with your actual stage.',
  fields: [
    { name: 'name', label: 'Skill', type: 'text', required: true },
    { name: 'category', label: 'Category', type: 'select', required: true, options: SKILL_CATEGORIES },
    { name: 'stage', label: 'Learning stage', type: 'select', required: true, options: SKILL_STAGES },
    { name: 'description', label: 'Description', type: 'textarea' },
    { name: 'cert_ids', label: 'Connected certificates', type: 'multiref', table: 'certificates', labelCol: 'title' },
    { name: 'project_ids', label: 'Connected projects', type: 'multiref', table: 'projects', labelCol: 'title' },
    { name: 'is_public', label: 'Show on public site', type: 'checkbox' },
  ],
  subtitle: (r) =>
    [r.category, r.stage, (r.cert_ids || []).length + (r.project_ids || []).length ? `${(r.cert_ids || []).length + (r.project_ids || []).length} connections` : '']
      .filter(Boolean)
      .join(' · '),
  filters: [{ label: 'Categories', get: (r) => r.category ?? '' }],
};

export default function SkillsPage() {
  return <ResourceManager config={config} />;
}
